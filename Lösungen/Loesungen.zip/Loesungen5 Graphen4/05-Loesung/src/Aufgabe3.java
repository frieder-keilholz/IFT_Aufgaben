import graph.*;
import graph.algorithm.*;

public class Aufgabe3 {

	public Aufgabe3() throws Exception {
		Graph graph = new GraphImpl(false);
		Vertex  v1, v2, v3, v4, v5, v6, v7, v8;

		// Beispielgraph aus der Vorlesung
		v1 = new Vertex( "1" );
		v2 = new Vertex( "2" );
		v3 = new Vertex( "3" );
		v4 = new Vertex( "4" );
		v5 = new Vertex( "5" );
		v6 = new Vertex( "6" );
		v7 = new Vertex( "7" );
		v8 = new Vertex( "8" );

		graph.add( v1 );
		graph.add( v2 );
		graph.add( v3 );
		graph.add( v4 );
		graph.add( v5 );
		graph.add( v6 );
		graph.add( v7 );
		graph.add( v8 );
		graph.addEdge( v1, v2 );
		graph.addEdge( v1, v5 );
		graph.addEdge( v1, v6 );
		graph.addEdge( v2, v3 );
		graph.addEdge( v2, v4 );
		graph.addEdge( v2, v5 );
		graph.addEdge( v2, v8 );
		graph.addEdge( v3, v4 );
		graph.addEdge( v3, v6 );
		graph.addEdge( v4, v8 );
		graph.addEdge( v5, v6 );
		graph.addEdge( v5, v7 );
		graph.addEdge( v6, v8 );
		graph.addEdge( v7, v8 );

		// Teste Faerbung
		System.out.println("Graph:\n" + graph);
		GraphColoring gc = new GreedyColoring( graph );
		System.out.println("Faerbung (Greedy): " + gc.coloring());
		gc = new BackTrackColoring( graph );
		System.out.println("Faerbung (Backtracking): " + gc.coloring());
	}

	public static void main(String[] args) throws Exception {
		@SuppressWarnings("unused")
		Aufgabe3 test = new Aufgabe3();
	}
}
