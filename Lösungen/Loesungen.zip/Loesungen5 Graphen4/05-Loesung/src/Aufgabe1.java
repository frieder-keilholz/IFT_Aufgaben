import graph.*;

public class Aufgabe1 {

	public Aufgabe1() throws Exception {
		DirectedAcyclicGraph graph = new DirectedAcyclicGraphImpl();
		Vertex  v1, v2, v3, v4, v5, v6, v7;

		// Graphen mit den Teilprojektabhaengigkeiten erzeugen
		v1 = new Vertex( "T1" );
		v2 = new Vertex( "T2" );
		v3 = new Vertex( "T3" );
		v4 = new Vertex( "T4" );
		v5 = new Vertex( "T5" );
		v6 = new Vertex( "T6" );
		v7 = new Vertex( "T7" );

		// Kanten geben die direkten Abhaengigkeiten an
		try {
			graph.addEdge( v3, v2 );  // T2 setzt die Ergebnisse von T3
			graph.addEdge( v4, v2 );  // und T4 voraus
			graph.addEdge( v6, v3 );
			graph.addEdge( v1, v4 );
			graph.addEdge( v4, v5 );
			graph.addEdge( v6, v5 );
			graph.addEdge( v7, v5 );
			graph.addEdge( v1, v6 );
			graph.addEdge( v3, v7 );
//			graph.addEdge( v7, v6 ); // Test: Diese Kante macht den Graphen zyklisch!
		} catch (CycleException e) {
			System.err.println("Der definierte Graph ist nicht azyklisch!");
			return;
		}

		System.out.println("Graph:\n" + graph);
		// Topologische Sortierung berechnen und ausgeben
		System.out.println("Topologische Sortierung (Arbeitsreihenfolge): " +
				graph.topologicalSort());

	}

	public static void main(String[] args) throws Exception {
		@SuppressWarnings("unused")
		Aufgabe1 test = new Aufgabe1();
	}
}
