import graph.Graph;
import graph.GraphImpl;
import graph.Vertex;
import graph.algorithm.BackTrackColoring;
import graph.algorithm.GraphColoring;
import graph.algorithm.GreedyColoring;
import graph.algorithm.JohnsonColoring;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

public class Test {

	public Test() throws Exception {
		Graph graph = new GraphImpl(false);
		Vertex vertex;
		List<Vertex> vertexes = new ArrayList<>();

		int COUNT = 15;

		for(int i=1; i <= COUNT; i++) {
			vertex = new Vertex(i);
			vertexes.add(vertex);
			graph.add(vertex);
		}

		for (int i=1; i <= COUNT; i++) {
			for (int j=1; j <= COUNT; j++) {
				if (i == j)
					continue;
				if (((i % 2) + (j % 2) == 0) || ((i % 4) + (j % 4) == 0) || (isPrime(i) && isPrime(j)))
					graph.addEdge(vertexes.get(i - 1), vertexes.get(j - 1));
			}
		}

		// Teste Faerbung
		System.out.println("Graph:\n" + graph);
		GraphColoring gc = new GreedyColoring( graph );
		System.out.println("Faerbung (Greedy): " + gc.coloring());
		gc = new JohnsonColoring( graph );
		System.out.println("Faerbung (Johnson): " + gc.coloring());
	}

	public static boolean isPrime(int number) {
		int sqroot = (int)Math.sqrt(number);
		return IntStream.rangeClosed(2, sqroot).noneMatch(i -> number % i == 0);
	}

	public static void main(String[] args) throws Exception {
		@SuppressWarnings("unused")
        Test test = new Test();
	}
}
