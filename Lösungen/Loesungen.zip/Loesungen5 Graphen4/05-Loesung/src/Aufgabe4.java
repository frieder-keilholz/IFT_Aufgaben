import graph.Graph;
import graph.GraphImpl;
import graph.Vertex;
import graph.algorithm.BackTrackColoring;
import graph.algorithm.GraphColoring;

import java.util.Collections;
import java.util.Vector;


/**
 * Minimum coloring for 5.4.
 */
public class Aufgabe4  {

  public static void main(String[] args) {
    Vector<Vertex> v = new Vector<Vertex>();
    // generate Antenna objects with Coordinates
    Antenna p1 = new Antenna("A1", 1, 4);
    Antenna p2 = new Antenna("A2", 3, 2);
    Antenna p3 = new Antenna("A3", 7, 5);
    Antenna p4 = new Antenna("A4", 8, 10);
    Antenna p5 = new Antenna("A5", 4, 7);
    Antenna p6 = new Antenna("A6", 5, 2);

    Graph graph = new GraphImpl(false);
    // generate Vertices with Antenna objects
    Vertex a1 = new Vertex(p1);
    Vertex a2 = new Vertex(p2);
    Vertex a3 = new Vertex(p3);
    Vertex a4 = new Vertex(p4);
    Vertex a5 = new Vertex(p5);
    Vertex a6 = new Vertex(p6);
    // add the Vertices to a Vector for computing distance
    v.add(a1);
    v.add(a2);
    v.add(a3);
    v.add(a4);
    v.add(a5);
    v.add(a6);

    try {
      //adding Vertices to Graph
      graph.add(a1);
      graph.add(a2);
      graph.add(a3);
      graph.add(a4);
      graph.add(a5);
      graph.add(a6);
      
      // compute distance
      for (int i = 0; i < v.size(); i++) {
        Vertex v1 = v.elementAt(i);
        for (int j = i + 1; j < v.size(); j++) {
          Vertex v2 = v.elementAt(j);
          Antenna antenna1 = (Antenna) v1.getObject();
          Antenna antenna2 = (Antenna) v2.getObject();
          double d = antenna1.distance(antenna2);
          if (d <= 5d) {
            System.out.println("adding edge: " + v1 + "->" + v2
                + " with distance: " + d);
            graph.addEdge(v1, v2);
          }
        }
      }
      
      // Backtracking algorithm computes minimum colors needed
      GraphColoring n = new BackTrackColoring(graph);
      System.out.println(n.coloring());
      
      int minColors = (Integer)Collections.max(n.getColorMap().values());
      System.out.println("Minimum Colors: " + minColors);

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
