import java.awt.Point;

/**
 * This class represents an Antenna with a description
 * and its coordinates.
 * 
 * @see Point
 */
public class Antenna extends Point {

	private static final long serialVersionUID = 1L;

	/** Description of the Antenna */
	private String description = "";

	/**
	 * Constructor.
	 * 
	 * @param description The Description
	 * @param x X Coordinate
	 * @param y Y Coordinate
	 */
	public Antenna(String description,int x,int y) {
		this.description = description;
		super.x = x;
		super.y = y;
	}

	/**
	 * Return the Description.
	 * 
	 * @return String The Description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Set the Description.
	 * 
	 * @param description The Description as String
	 */
	public void setDescription(String description) {
		this.description = description;
	}
}
