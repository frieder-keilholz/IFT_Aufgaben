/**
 * Aufgabe 6 (Sudoku solver)
 * 
 * @author Ralf Vandenhouten
 */
public class Aufgabe5 {

	public static void main(String[] args) throws Exception {
		SudokuSolver sudoku = new SudokuSolver("Sudoku1.txt");
		long t1 = System.currentTimeMillis();
		sudoku.solve();
		long t2 = System.currentTimeMillis();
		System.out.println(sudoku);
		System.out.println("Solved in " + (t2-t1) + "ms.");
	}
}
