import graph.*;
import graph.algorithm.*;

import java.awt.Point;

public class Aufgabe3 {

	public Aufgabe3() throws Exception {
		WeightedGraph graph = new WeightedGraphImpl( false );
		Vertex  v[][] = new Vertex[10][10];
		int i, j;

		// Zunaechst das vollstaendige Grid anlegen
		for (i=0; i<10; i++)
			for (j=0; j<10; j++) {
				// Wir verwenden einen Point als Vertex-Objekt, damit jeder
				// Knoten "weiss", wo er sich befindet.
				Point point = new MyPoint(i, j);
				v[i][j] = new Vertex( point );
				graph.add( v[i][j] );
			}
		for (i=0; i<10; i++)
			for (j=0; j<10; j++) {
				if ( i < 9 )
					graph.addEdge( v[i][j], v[i+1][j], 1 );
				if ( j < 9 )
					graph.addEdge( v[i][j], v[i][j+1], 1 );
			}

		// Nun die Hindernisse einfuegen, in dem die entsprechenden Knoten entfernt
		// werden
		graph.remove( v[1][0] );
		graph.remove( v[1][1] );
		graph.remove( v[1][2] );
		graph.remove( v[2][1] );
		graph.remove( v[2][5] );
		graph.remove( v[2][6] );
		graph.remove( v[2][7] );
		graph.remove( v[3][1] );
		graph.remove( v[3][5] );
		graph.remove( v[4][5] );
		graph.remove( v[5][0] );
		graph.remove( v[5][1] );
		graph.remove( v[5][2] );
		graph.remove( v[5][3] );
		graph.remove( v[5][5] );
		graph.remove( v[6][6] );
		graph.remove( v[6][7] );
		graph.remove( v[7][2] );
		graph.remove( v[7][3] );
		graph.remove( v[8][2] );
		graph.remove( v[8][3] );
		graph.remove( v[8][4] );

		System.out.println("\n************ Aufgabe 3 ******************");
		Vertex start = v[5][8], target = v[3][0];
		long t1 = System.currentTimeMillis();
		ShortestPathAlgorithmDijkstra spd = new ShortestPathAlgorithmDijkstra(graph);
		System.out.println("Kuerzester Weg mit Dijkstra: " + 
				spd.getShortestPath(start, target));
		long t2 = System.currentTimeMillis();
		ShortestPathWithEstimator spwe =
			new ShortestPathWithEstimator( graph, new MyEstimator( target ) );
		System.out.println("Kuerzester Weg mit iterativem A*: " +
				spwe.getShortestPath( start, target ) );
		long t3 = System.currentTimeMillis();
		System.out.println("Time for Dijkstra: " + (t2-t1));
		System.out.println("Time for iterative A*: " + (t3-t2));
	}

	public static void main(String[] args) throws Exception {
		new Aufgabe3();
	}
}
