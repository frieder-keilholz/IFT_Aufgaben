package graph.algorithm;

import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

import graph.Estimator;
import graph.Graph;
import graph.Vertex;


/**
 * A greedy algorithm for quickly finding a path from a start vertex 
 * to a target vertex by means of an estimation function.
 * 
 * @author Ralf Vandenhouten
 */
public class GreedyPathWithEstimator {
    /**
     * The Graph object that the algorithm uses to determine
     * the path.
     */
    private Graph graph;
    /**
     * Estimator object that estimates the distance of a vertex to the target
     * vertex.
     */
    private Estimator estimator;
    /**
     * List containing the edges of the shortest path
     */
    private List<Vertex> path;

    /**
     * Creates an instance of ShortestPathAlgorithmEstimator.
     *
     * @param graph The Graph where a shortest path will be determined
     * @param estimator The Estimator object that estimates the distance of each
     *    vertex from the target vertex.
     */
    public GreedyPathWithEstimator(Graph graph, Estimator estimator) {
        this.graph = graph;
        this.estimator = estimator;
    }

    /**
     * Determines a path from a given start vertex to the target vertex
     * using a greedy strategy.
     *
     * @param start The start vertex for the search
     * @param target The target vertex of the search
     * @return A List containing the vertices that the path from the
     *         start vertex to the target vertex consists of.
     */
    public List<Vertex> findPath( Vertex start, Vertex target ) {
        if ( start == null || target == null )
            return null;
        
        // Initialize the priority queue.
        // A node with a better (shorter) distance estimation has higher priority.
        PriorityQueue<PathNode> priorityQueue = 
            new PriorityQueue<PathNode>(100, new Comparator<PathNode>() {
                public int compare(PathNode o1, PathNode o2) {
                    return o1.priority < o2.priority ? -1 : 1;
                }
            });
        priorityQueue.add(new PathNode(start, null, estimator.estimate(start, target)));
        HashSet<Vertex> visited = new HashSet<Vertex>();
        visited.add(start);
        PathNode found = null;

        // Greedy search of the target with priority queue
        while (!priorityQueue.isEmpty()) {
            PathNode current = priorityQueue.remove();
            Vertex vertex = current.node;
            if (vertex == target) {
                found = current;
                break;
            }
            for (Vertex neighbor: graph.getAdjacentVertices(vertex)) {
                if (!visited.contains(neighbor)) {
                    double distance = estimator.estimate(neighbor, target);
                    priorityQueue.add(new PathNode(neighbor, current, distance));
                    visited.add(neighbor);
                }
            }
        }

        // Generate the path as a vertex list
        if (found == null) {
            path = null;
        } else {
            path = new LinkedList<Vertex>();
            do {
                path.add(0, found.node);
                found = found.predecessor;
            } while (found != null);
        }
        System.out.println("Visited nodes: " + visited.size());
        return path;
    }

    /**
     * Helper class used to store a node of the path in the priority queue
     */
    private class PathNode {
        Vertex node;
        PathNode predecessor;
        double priority;
        
        public PathNode(Vertex node, PathNode predecessor, double priority) {
            this.node = node;
            this.predecessor = predecessor;
            this.priority = priority;
        }
    }
}
