package graph;

/**
 * An interface for an estimator that maps vertices or pairs of vertices
 * to (real number) estimation values. This can be used e.g. for optimizing
 * shortest path search algorithms.
 */
public interface Estimator {
  /**
   * This method computes a real number representing the estimation value
   * of a vertex.
   *
   * @param vertexToEstimate nomen est omen
   * @return The estimation value of the vertex.
   */
  public double estimate(Vertex vertexToEstimate);
  /**
   * Estimates the relation between two vertices v1 and v2.
   *
   * @param v1 The first vertex to be estimated.
   * @param v2 The second vertex to be estimated.
   * @return The estimation value of the relation (v1,v2).
   */
  public double estimate(Vertex v1, Vertex v2);
}
