import java.awt.Point;

/**
 * Punktklasse
 * @author Ralf Vandenhouten
 */
public class MyPoint extends Point
{
	private static final long serialVersionUID = -405623729666829627L;

	public MyPoint(int x, int y) {
		super(x, y);
	}

	public String toString() {
		return "[" + this.x + "," + this.y + "]";
	}
}
