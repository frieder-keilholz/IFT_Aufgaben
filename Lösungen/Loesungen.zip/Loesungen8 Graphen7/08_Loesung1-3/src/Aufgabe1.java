import graph.*;
import graph.algorithm.*;

import java.awt.*;

public class Aufgabe1 {

	public Aufgabe1() throws Exception {
		WeightedGraph graph = new WeightedGraphImpl( false );
		Vertex  v[] = new Vertex[9];

		v[0] = new Vertex( "Takamatsu" );
		v[1] = new Vertex( "Kawanoe" );
		v[2] = new Vertex( "Tokushima" );
		v[3] = new Vertex( "Ikeda" );
		v[4] = new Vertex( "Matsuyama" );
		v[5] = new Vertex( "Kochi" );
		v[6] = new Vertex( "Uwajima" );
		v[7] = new Vertex( "Nakamura" );
		v[8] = new Vertex( "Muroto" );

		graph.add( v[0] );
		graph.add( v[1] );
		graph.add( v[2] );
		graph.add( v[3] );
		graph.add( v[4] );
		graph.add( v[5] );
		graph.add( v[6] );
		graph.add( v[7] );
		graph.add( v[8] );

		graph.addEdge( v[0], v[1], 73 );
		graph.addEdge( v[0], v[2], 76 );
		graph.addEdge( v[0], v[3], 57 );
		graph.addEdge( v[1], v[3], 26 );
		graph.addEdge( v[1], v[4], 95 );
		graph.addEdge( v[1], v[5], 87 );
		graph.addEdge( v[2], v[3], 74 );
		graph.addEdge( v[2], v[8], 128 );
		graph.addEdge( v[3], v[5], 82 );
		graph.addEdge( v[4], v[5], 127 );
		graph.addEdge( v[4], v[6], 92 );
		graph.addEdge( v[5], v[6], 148 );
		graph.addEdge( v[5], v[7], 128 );
		graph.addEdge( v[5], v[8], 83 );
		graph.addEdge( v[6], v[7], 87 );

		System.out.println("\n************ Aufgabe 1 ******************");
		System.out.println("\nLoesung mit Floyd-Algorithmus:");
		long timer = System.currentTimeMillis();
		ShortestPathAlgorithm spf =
				new ShortestPathAlgorithmFloyd( graph );
		// Hier werden bereits die Distanzen fur jedes Eckenpaar berechnet und in den Matrizen abgespeichert
		spf.shortestPath();
		timer = System.currentTimeMillis() - timer;
		System.out.println("Zeit fuer Initialisierung: " + timer + "ms");
		timer = System.currentTimeMillis();
		// Für jede Stadt wird zu jeder anderen Stadt die kuerzeste Entfernung ausgegeben (Zugriff auf Distance-Matrix).
		for (int i=0; i<9; i++)
			for (int j=i+1; j<9; j++)
				System.out.println("Entfernung von " + v[i] + " nach " + v[j] + ": "
						+ spf.getDistance( v[i], v[j] ) );
		timer = System.currentTimeMillis() - timer;
		System.out.println("Dauer: " + timer + "ms\n");

		System.out.println("Loesung mit Dijkstra-Algorithmus:");
		timer = System.currentTimeMillis();
		ShortestPathAlgorithm spd =
			new ShortestPathAlgorithmDijkstra( graph );
		timer = System.currentTimeMillis() - timer;
		System.out.println("Zeit fuer Initialisierung: " + timer + "ms");
		timer = System.currentTimeMillis();
		for (int i=0; i<9; i++)
			// Hier wird der jeweilige kW-Baum für jede Stadt berechnet und davon ausgehend die kuerzeste Distanz zu
			// jeder anderen Stadt berechnet
			for (int j=i+1; j<9; j++)
				System.out.println("Entfernung von " + v[i] + " nach " + v[j] + ": "
						+ spd.getDistance( v[i], v[j] ) );
		timer = System.currentTimeMillis() - timer;
		System.out.println("Dauer: " + timer + "ms");
	}
	
	public static void main(String[] args) throws Exception {
		new Aufgabe1();
	}
}
