import graph.Estimator;
import graph.Vertex;

import java.awt.Point;


/**
 * Klasse fuer die Schaetzfunktion
 * @author Ralf Vandenhouten
 */
public class MyEstimator implements Estimator {
    Vertex target;

    public MyEstimator( Vertex target ) {
        this.target = target;
    }

    public double estimate( Vertex vertexToEstimate ) {
        return estimate(vertexToEstimate, target);
    }

    public double estimate( Vertex v1, Vertex v2 ) {
        Point point = (Point)v1.getObject();
        int x1 = point.x;
        int y1 = point.y;
        point = (Point)v2.getObject();
        int x2 = point.x;
        int y2 = point.y;
        int dx = x1 - x2;
        int dy = y1 - y2;
        // Gute Schaetzfunktion (kuerzester Abstand ohne Hindernisse):
        // return Math.abs( dx ) + Math.abs( dy );
        // Euklidischer Abstand als Schaetzfunktion:
        //return Math.sqrt(dx*dx + dy*dy);
        // Max-Norm als Schaetzfunktion:
        return Math.max(Math.abs(dx), Math.abs(dy));
        // Schlechte Schaetzfunktion (entspricht Dijkstra-Algorithmus)
        // return 0.0;
    }
}
