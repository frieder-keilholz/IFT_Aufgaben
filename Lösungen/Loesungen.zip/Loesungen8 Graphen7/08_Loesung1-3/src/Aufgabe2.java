import graph.*;
import graph.algorithm.*;

public class Aufgabe2 {

	public Aufgabe2() throws Exception {
		WeightedGraph graph = new WeightedGraphImpl( false );
		Vertex  v[] = new Vertex[100];
		int i, j, mini=-1;

		// Computer als Ecken des Graphen definieren
		for (i=0; i<100; i++) {
			v[i] = new Vertex(""+(i+1));
			graph.add( v[i] );
		}
		// Direktverbindungen als Kanten modellieren sowie deren Bewertung
		for (i=0; i<100; i++)
			for (j=i+1; j<100; j++)
				graph.addEdge( v[i], v[j], (i+1)*(j+1)+(i-j)*(i-j) );

		System.out.println("\n************ Aufgabe 2 ******************");
		// Voll vermaschter Graph, dafuer bietet sich der Floyd-Algorithmus an:
		ShortestPathAlgorithm spf =
			new ShortestPathAlgorithmFloyd( graph );
		spf.shortestPath();
		double d, minDistance = Double.POSITIVE_INFINITY;
		// Bestimme maximale Uebertragungszeiten fuer alle Knoten
		for (i=0; i<100; i++) {
			d = spf.getLongestDistance( v[i] );
			if ( d < minDistance ) {
				minDistance = d;
				mini = i;
			}
		}
		System.out.println("Optimaler Serverknoten: " + v[mini]);
		System.out.println("Maximale Uebertragungszeit: " + minDistance + " ms");
		System.out.println("Routing-Tabelle fuer den Server: " +
				spf.getRoutingTable( v[mini] ));
		System.out.println("Routing-Tabelle fuer Knoten 13: " +
				spf.getRoutingTable( v[12] ));
		System.out.println("Routing-Tabelle fuer Knoten 14: " +
				spf.getRoutingTable( v[13] ));
		/* Ergebnis:
		 * Es gibt nur vier weitere Router, die Knoten 13 (Router fuer die Knoten
		 * 1-4) und 14 (Router fuer die Knoten 5-8) sowie die Knoten 3 und 4. 
		 * Knoten 1 wird ueber 13 und 3, Knoten 2 ueber 13 und 4 angesteuert. 
		 * Alle anderen Knoten werden mit dem Server direkt verbunden.
		 */
	}

	public static void main(String[] args) throws Exception {
		new Aufgabe2();
	}
}

