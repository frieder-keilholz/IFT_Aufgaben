State14 ist (angeblich) 80 Züge vom Ziel entfernt, was dem Durchmesser des Graphen 
entspricht (also der maximal möglichen Distanz zwischen zwei Stellungen).
Auf dem MacBook Pro (2017) gibt es nach 24h noch keine Lösung (aktuelle Suchtiefe: 76 Züge,
also auch keine Lösung in Sicht).