/*
 * File PuzzleSolver.java
 * $Id$
 *
 * (c) Copyright 2008 Ralf Vandenhouten
 * All rights reserved
 */
package pushpuzzle;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Stack; 


/**
 * PuzzleSolver fuer Pushpuzzles bis zur Groesse 4x4.
 * @author Ralf Vandenhouten
 * @version $Revision$
 */
public class PuzzleSolver {

    private int width, height;
    private State start;
    private State end;
    
    /**
     * Konstruktor
     * @param width - Breite des Puzzles
     * @param height - Hoehe des Puzzles
     * @param start - Startzustand des Puzzles
     */
    public PuzzleSolver(int width, int height, State start) {
        this.width = width;
        this.height = height;
        this.start = start;
        this.end = new State(width, height);
    }
    
    /**
     * Konstruktor, der die Ausgangsstellung aus einer Datei mit diesem Formt liest: </br>
     * <width>
     * <height>
     * <Zahl11><Zahl12>...<Zahl1<width>>
     * ...
     * <Zahl<height>1>...<Zahl<height><width>>
     * 
     * @param filename - Name der Datei mit der Startstellung
     */
    public PuzzleSolver(String filename) {
    	try (BufferedReader in = new BufferedReader(
                new InputStreamReader(new FileInputStream(filename)));)
        {
            width = Integer.parseInt(in.readLine());
            height = Integer.parseInt(in.readLine());
            long signature = 0;
            for (int i=0; i<height; i++) {
                String s = in.readLine();
                for (int j=0; j<width; j++) {
                    char c = s.charAt(j);
                    long value;
                    if (Character.isDigit(c))
                        value = c - '0';
                    else
                        switch (c) {
                            case 'A':
                                value = 10;
                                break;
                            case 'B':
                                value = 11;
                                break;
                            case 'C':
                                value = 12;
                                break;
                            case 'D':
                                value = 13;
                                break;
                            case 'E':
                                value = 14;
                                break;
                            case 'F':
                                value = 15;
                                break;
                            default:
                                throw new NumberFormatException("Wrong input!!!");    
                        }
                    signature += value << (4*(i*width+j));
                }
            }
            start = new State(width, height, signature);
            System.out.println("Start state: " + start);
            end = new State(width, height);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Iterative Tiefensuche
     * @return das Ergebnis als Liste
     */
    public List<State> solve() {
        int maxDepth = start.estimateDistance();
        while (true) {
            System.out.println("Max. depth: " + maxDepth);
            List<State> result = solve(maxDepth++);
            if (result != null)
                return result;
        }
    }
    
    /**
     * Tiefensuche mit Stack
     * @param maxDepth - maximale Suchtiefe
     * @return das Ergebnis als Liste, wenn eines gefunden wurde, andernfalls null
     */
    public List<State> solve(int maxDepth) {
        List<State> result = new ArrayList<State>(maxDepth+1);
        HashSet<State> visited = new HashSet<State>();
        Stack<Iterator<State>> stack = new Stack<Iterator<State>>();
        result.add(start);
        visited.add(start);
        stack.push(start.getNeighborStates());
        int index = 0;

        while (!stack.empty()) {
            Iterator<State> it = stack.peek();
            if (it.hasNext()) {
                State state = it.next();
                if (state.equals(end)) { // fertig!
                    result.add(index+1, state);
                    return result;
                }
                if (index<maxDepth && !visited.contains(state)) { 
                    // Stellung wurde auf dem aktuellen Weg noch nicht besucht
                    // Also von hier aus weitermachen...
                    index++;
                    result.add(index, state);
                    visited.add(state);
                    stack.push(state.getNeighborStates());
                } else {
                    continue;
                }
            } else {
                // Von hier aus gibt es keine weiteren Moeglichkeiten mehr
                // Also zurueck...
                stack.pop();
                visited.remove(result.get(index));
                result.remove(index--);
            }
        }
        
        return null;
    }
    
    /**
     * Iterativer A*-Algorithmus
     * @return das Ergebnis als Liste
     */
    public List<State> solveWithEstimator() {
        int maxLength = start.estimateDistance();
        while (true) {
            System.out.println("Max. length: " + maxLength);
            List<State> result = solveWithEstimator(maxLength);
            maxLength += 2;
            if (result != null)
                return result;
        }
    }
    
    /**
     * A*-Suche mit beschraenkter Weglaenge
     * @param maxLength - maximale Gesamtweglaenge
     * @return das Ergebnis als Liste, wenn eines gefunden wurde, andernfalls null
     */
    public List<State> solveWithEstimator(int maxLength) {
        List<State> result = new ArrayList<State>(maxLength+1);
        HashSet<State> visited = new HashSet<State>();
        Stack<Iterator<State>> stack = new Stack<Iterator<State>>();
        result.add(start);
        visited.add(start);
        stack.push(start.getNeighborStates());
        int index = 0;

        while (!stack.empty()) {
            Iterator<State> it = stack.peek();
            if (it.hasNext()) {
                State state = it.next();
                int distance = state.estimateDistance();
                if (state.equals(end)) { // fertig!
                    result.add(index+1, state);
                    return result;
                }
                if (index+distance<maxLength && !visited.contains(state)) { 
                    // Stellung wurde auf dem aktuellen Weg noch nicht besucht
                    // Also von hier aus weitermachen...
                    index++;
                    result.add(index, state);
                    visited.add(state);
                    stack.push(state.getNeighborStates());
                } else {
                    continue;
                }
            } else {
                // Von hier aus gibt es keine weiteren Moeglichkeiten mehr
                // Also zurueck...
                stack.pop();
                visited.remove(result.get(index));
                result.remove(index--);
            }
        }
        
        return null;
    }
    
    /**
     * Greedy-Suche mit Schaetzfunktion 
     * (liefert i.allg. suboptimalen Loesungsweg, den aber extrem schnell)
     * @return das Ergebnis als Liste, wenn eines gefunden wurde, andernfalls null
     */
    public List<State> solveGreedyWithEstimator() {
        HashSet<State> visited = new HashSet<State>();
        PriorityQueue<PathNode> priorityQueue = 
            new PriorityQueue<PathNode>(1000, new Comparator<PathNode>() {
                public int compare(PathNode o1, PathNode o2) {
                    return o1.priority < o2.priority ? -1 : 1;
                }
            });
        visited.add(start);
        priorityQueue.add(new PathNode(start, null, start.estimateDistance()));
        PathNode found = null;

        // Greedy search
        while (!priorityQueue.isEmpty()) {
            PathNode current = priorityQueue.remove();
            State state = current.node;
            if (state.equals(end)) { // fertig!
            	found = current;
            	break;
            }
            for (State neighbor : state) {
            	if (!visited.contains(neighbor)) { 
            		// Stellung wurde auf dem aktuellen Weg noch nicht besucht
            		// Also von hier aus weitermachen...
            		visited.add(neighbor);
            		int distance = neighbor.estimateDistance();
            		priorityQueue.add(new PathNode(neighbor, current, distance));
            	} 
            }
        }
        
        // Generate the solution path as a State list
        if (found == null) {
            return null;
        } else {
            List<State> result = new LinkedList<State>();
            do {
                result.add(0, found.node);
                found = found.predecessor;
            } while (found != null);
            return result;
        }
    }
    
    /**
     * Helper class used to store a node of the path in the priority queue (for greedy algorithm)
     */
    private class PathNode {
        State node;
        PathNode predecessor;
        int priority;
        
        public PathNode(State node, PathNode predecessor, int priority) {
            this.node = node;
            this.predecessor = predecessor;
            this.priority = priority;
        }
    }
    
    /**
     * Hauptprogramm
     */
    public static void main(String[] args) {
//        State state = new State(3, 3);
//        System.out.println("" + state + state.getSignature());
//        for (State neighb: state)
//            System.out.println(neighb);
        PuzzleSolver ps = new PuzzleSolver("State10.txt");
        long time = System.currentTimeMillis();
//        List<State> result = ps.solve();
       List<State> result = ps.solveWithEstimator();
//        List<State> result = ps.solveGreedyWithEstimator();
        time = System.currentTimeMillis() - time;
        if (result != null)
        	System.out.println("Solution with " + (result.size()-1) 
        			+ " moves found in " + time + "ms:\n\n" + result);
        else
        	System.out.println("No solution found in " + time + "ms.");
    }
}
