import com.em.common.model.EmployeeService;

module com.em.consumer {

	requires com.em.common;
	// requires com.em.service; -- Muss nicht angegeben werden, hier reicht es das Modul im Classpath (Module Settings)
	//                          -- bekannt zu machen, damit das Modul mitgestartet wird (zur Laufzeit).

	uses EmployeeService;
}
