package com.em.service.consumer;

import com.em.common.model.Employee;
import com.em.common.model.EmployeeService;

import java.util.Optional;
import java.util.ServiceLoader;

public class EmployeeServiceTest {

    public static void main(String[] args) {


        ServiceLoader<EmployeeService> serviceLoader = ServiceLoader.load(EmployeeService.class);
        // Initializing the implementation of the EmployeeService
        Optional<EmployeeService> optional = serviceLoader.findFirst();

        if (!optional.isPresent())
            return;

        EmployeeService service = optional.get();
        Employee e = service.getEmployee();

        System.out.println(e.getFirstName());
        System.out.println(e.getLastName());
        System.out.println(e.getDesignation());
    }

}
