import com.em.common.model.EmployeeService;
import com.em.service.employee.EmployeeServiceImpl;

module com.em.service {

	requires com.em.common;
	provides EmployeeService with EmployeeServiceImpl;
}
