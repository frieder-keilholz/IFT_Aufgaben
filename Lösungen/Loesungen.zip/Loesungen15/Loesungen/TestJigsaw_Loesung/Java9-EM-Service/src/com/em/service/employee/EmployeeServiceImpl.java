package com.em.service.employee;

import com.em.common.model.Employee;
import com.em.common.model.EmployeeService;

public class EmployeeServiceImpl implements EmployeeService {

    public Employee getEmployee() {

        Employee employee = new Employee();
        employee.setFirstName("Peter");
        employee.setLastName("Milanovich");
        employee.setDesignation("Scrum Master");

        return employee;
    }

}
