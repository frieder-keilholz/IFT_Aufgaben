module com.em.common {
	exports com.em.common.model;
}
