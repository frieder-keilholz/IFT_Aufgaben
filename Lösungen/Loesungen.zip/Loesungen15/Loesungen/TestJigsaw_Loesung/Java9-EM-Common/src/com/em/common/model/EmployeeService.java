package com.em.common.model;

public interface EmployeeService {

	Employee getEmployee();
}
