package de.thwildau.tm.java8.person;

import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class PersonStreams {

	public static void main(String[] args) throws Exception {

		List<Person> people = PersonReader.readPersons("personenliste.txt");
		
		//Predicate<Person> isAdult = Person::isAdult;
		//Predicate<Person> isNotAdult = isAdult.negate();
		
		Map<Integer,Long> histogram = people.parallelStream()
			.filter(p -> p.getName().startsWith("J"))
			.filter(p -> !p.isAdult()) // younger than 18
			.collect(Collectors.groupingBy(Person::getAge, Collectors.counting()));
		System.out.println("Frequency(Age): " + histogram);
	}

}
