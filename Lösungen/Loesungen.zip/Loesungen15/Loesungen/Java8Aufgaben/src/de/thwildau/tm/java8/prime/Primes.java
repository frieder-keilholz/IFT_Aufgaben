package de.thwildau.tm.java8.prime;

import java.util.function.IntPredicate;
import java.util.stream.IntStream;

public class Primes {

	/**
	 * Check if the given number is a prime number
	 * @param number - the integer number to be checked
	 * @return <code>true</code> if the number is a prime, otherwise <code>false</code>
	 */
	public static boolean isPrime(int number) {
		int sqroot = (int)Math.sqrt(number);
		return IntStream.rangeClosed(2, sqroot).noneMatch(i -> number % i == 0);
	}
	
	/**
	 * Print out all integer numbers < 1000
	 */
	public static void main(String[] args) {
		long t1 = System.currentTimeMillis();
		
		IntPredicate onlyPrimes = Primes::isPrime;
		
		// Print all primes below 10.000
		IntStream.range(2, 10000).parallel().filter(onlyPrimes)
		.forEach(x -> System.out.println(x));
		
		t1 = System.currentTimeMillis() - t1;
		System.out.println("Time: " + t1 + "ms.");
	}
}
