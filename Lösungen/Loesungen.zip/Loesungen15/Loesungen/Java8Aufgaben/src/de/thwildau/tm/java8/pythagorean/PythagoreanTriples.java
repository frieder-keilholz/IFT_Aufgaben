package de.thwildau.tm.java8.pythagorean;

import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import de.thwildau.tm.java8.prime.Primes;

/**
 * Class for generating Pythagorean triples
 * @author Ralf Vandenhouten
 */
public class PythagoreanTriples {

	public static final int LIMIT = 10000;
	
	public static void main(String[] args) {
	
		Stream<int[]> pythagoreanTriples =
				IntStream.rangeClosed(1, LIMIT).parallel().boxed()
				.flatMap(a -> IntStream.rangeClosed(a, LIMIT)
						.mapToObj(b -> new double[] {a, b, Math.sqrt(a*a + b*b)})
						.filter(x -> x[2] % 1 == 0)) // Check if c is an integer
				.map(x -> new int[] {(int)x[0], (int)x[1], (int)x[2]});
		
		System.out.println("Pythagorean triples:");
		pythagoreanTriples.forEach(x -> System.out.println("("+x[0]+","+x[1]+","+x[2]+")"));

		//Predicate<T> definiert eine Methode boolean test(T t),
		//die gut als Filterbedingung verwendet werden kann
		Predicate<int[]> primes = x -> Primes.isPrime(x[0]) /*&& Primes.isPrime(x[1])*/ && Primes.isPrime(x[2]);
		Stream<int[]> pythagoreanPrimeTriples = 
				IntStream.rangeClosed(1, LIMIT).parallel().boxed()
				.flatMap(a -> IntStream.rangeClosed(a, LIMIT)
						.mapToObj(b -> new double[] {a, b, Math.sqrt(a*a + b*b)})
						.filter(x -> x[2] % 1 == 0)) // Check, ob c ein Integer ist (natuerliche Zahl)
				.map(x -> new int[] {(int)x[0], (int)x[1], (int)x[2]})
				.filter(primes);

		System.out.println("Pythagorean triples with prime numbers:");
		pythagoreanPrimeTriples.forEach(x -> System.out.println("("+x[0]+","+x[1]+","+x[2]+")"));
	}
}
