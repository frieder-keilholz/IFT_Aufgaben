package de.thwildau.tm.java8.person;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

/**
 * Sample class for demonstrating Java 8 features
 *
 * @author Ralf Vandenhouten
 */
public class Person {

	private String name;
	private LocalDate birthday; // <-- Changed from int to LocalDate!
	private boolean male;
	
	public Person(String name, LocalDate birthday, boolean male) {
		this.name = name;
		this.birthday = birthday;
		this.male = male;
	}

	/**
	 * @return the age in years at the end of this year
	 */
	public int getAge() {
		// Changed!
		LocalDate today = LocalDate.now();  
		return Period.between(birthday, today).getYears();
	}
	
	public boolean isAdult() {
		return getAge() >= 18;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getYearOfBirth() {
		return birthday.getYear(); // <-- Changed!
	}

	public boolean isMale() {
		return male;
	}

	public void setMale(boolean male) {
		this.male = male;
	}
	
    @Override
    public int hashCode() {
        return name.hashCode() + birthday.hashCode(); // <-- Changed!
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Person other = (Person)obj;
        return name.equals(other.name) && birthday.equals(other.birthday); // <-- Changed!
    }

	@Override
	public String toString() {
		return name + " (" + getYearOfBirth() + ")";
	}

	public static List<Person> createPersons() {
		List<Person> people = new ArrayList<>();
		people.add(new Person("Mick", LocalDate.parse("1999-04-28"), true));
		people.add(new Person("Alice", LocalDate.parse("1981-12-18"), false));
		return people;
	}
}
