package de.thwildau.tm.java8.person;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


/**
 * An example class demonstrating parsing of a text file using Java7 try-blocks and 
 * Java8 time classes 
 * 
 * @author Ralf Vandenhouten
 */
public class PersonReader {

	/**
	 * Reads a list of {@link Person}s from a file
	 * @param filename
	 * @return the list of persons
	 * @throws Exception
	 */
    public static List<Person> readPersons(String filename) throws Exception {
        List<Person> list = new ArrayList<>();
        try(Scanner scanner = new Scanner(new File(filename))) {
            // skip the first header line
            scanner.nextLine();
            while (scanner.hasNextLine()) {
                try(Scanner ls = new Scanner(scanner.nextLine())) {
                    ls.useDelimiter(",");
                    String name = ls.next();
					Integer.parseInt(ls.next()); // birthyear is not used anymore
                    String birthday = ls.next();
                    boolean male = Boolean.parseBoolean(ls.next());                    
                    
                    // convert the date string with the new Java8 DateTimeFormatter class
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
                    LocalDate birthDate = LocalDate.parse(birthday, formatter);
                    
                    // create the person and add them to the list
                    Person p = new Person(name, birthDate, male); // Changed birthyear to birthdate
                    list.add(p);
                }
            }
        }
        return list;
    }

}
