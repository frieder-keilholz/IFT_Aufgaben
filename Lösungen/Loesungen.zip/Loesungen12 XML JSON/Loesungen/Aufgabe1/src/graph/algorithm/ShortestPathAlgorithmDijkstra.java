package graph.algorithm;

import graph.*;
import util.*;
import java.util.*;

/**
 * A concrete implementation of ShortestPathAlgorithm using Dijkstra's method.
 * Note that the Dijkstra method can only be used for graphs with
 * non-negative edge weights.
 * 
 * @author Jesus M. Salvo Jr., Ralf Vandenhouten
 * @version 2.0 2010-09-16
 */
public class ShortestPathAlgorithmDijkstra extends ShortestPathAlgorithm {

	private static final long serialVersionUID = 2L;

	/**
	 * List of vertices that has been added to the tree
	 */
	private HashSet<Vertex> visited;

	/**
	 * Heap of FringeObjects that are to be processed.
	 */
	private PriorityQueue<HeapNode> fringe;

	/**
	 * HashMap for fast detection of a vertex' heapnode
	 */
	private HashMap<Vertex,HeapNode> fringeMap;

	/**
	 * Subgraph forming the shortest spanning tree.
	 */
	private WeightedGraph shortestpathtree;

	/**
	 * Comparator used to be compare priorities in the fringe.
	 */
	private HeapNodeComparator  comparator;

	/**
	 * Creates an instance of ShortestPathAlgorithmDijkstra.
	 *
	 * @param wgraph  The WeightedGraph where a shortest path spanning tree will be determined.
	 * @param comparator  The HeapNodeComparator to be used to compare priorities of objects in the fringe/heap.
	 */
	public ShortestPathAlgorithmDijkstra( WeightedGraph wgraph, HeapNodeComparator comparator ) {
		super( wgraph );
		this.visited = new HashSet<Vertex>();
		this.comparator = comparator;
		this.fringe = new PriorityQueue<HeapNode>( wgraph.getVerticesCount(), new HeapNodeComparator( -1 ) );
		this.fringeMap = new HashMap<Vertex,HeapNode>();
	}

	/**
	 * Creates an instance of ShortestPathAlgorithmDijkstra using the default
	 * HeapNodeComparator.
	 *
	 * @param wgraph  The WeightedGraph where a shortest path spanning tree will be determined.
	 */
	public ShortestPathAlgorithmDijkstra( WeightedGraph wgraph ) {
		this( wgraph, new HeapNodeComparator(-1) );
	}

	/**
	 * Determines the shortest path from a given vertex to all other vertices
	 * that are in the same connected set as the given vertex in the weighted graph
	 * using Dijkstra's algorithm.
	 *
	 * @return  A WeightedGraph comprising of the shortest path spanning tree.
	 */
	public WeightedGraph shortestPath() {
		if ( startVertex == null )
			return null;

		// clear the graph.
		this.shortestpathtree = new WeightedGraphImpl( true );

		// Now add the vertex we are interested in to the fringe.
		HeapNode hn = new HeapNode( new FringeObject( startVertex, null ), 0.0 );
		this.fringe.add( hn );
		this.fringeMap.put( startVertex, hn );

		// Continually process while there are vertices in the heap.
		while ( !this.fringe.isEmpty() ) {
			// Moves the highest priority node from the heap to the tree.
			this.moveToVisited();
		}

		// Clear the vectors
		this.visited.clear();
		this.fringe.clear();
		this.fringeMap.clear();

		return shortestpathtree;
	}

	/**
	 * Moves the vertex that has the highest priority in the heap
	 * from the fringe to the tree
	 */
	private void moveToVisited() {
		HeapNode  prioritynode;

		// Remove the node with highest priority from the fringe ...
		prioritynode = this.fringe.remove( );

		FringeObject fringeobject = (FringeObject) prioritynode.getObject();
		Vertex priorityvertex = fringeobject.vertex;

		this.fringeMap.remove( priorityvertex );

		// ... and add it to the tree.
		this.visited.add( priorityvertex );
		if( fringeobject.edge != null ) {
			try {
				this.shortestpathtree.addEdge( fringeobject.edge );
			}
			catch( Exception ex ) {
				ex.printStackTrace();
			}
		}

		// ... then move all the adjacent vertices of the vertex
		// we just moved to the tree and put them in the fringe.
		this.moveAdjacentVerticesToFringe( prioritynode );
	}

	/**
	 * Gets all the adjacent vertices from unseen to the fringe.
	 * The parameter vertex must be a vertex that is being moved
	 * from the fringe to the tree. This method must only be called
	 * by the method moveToVisited().
	 *
	 * @param vertex  The vertex that is being moved from the fringe to the tree
	 * and whose adjacent vertices we want added to the fringe.
	 */
	private void moveAdjacentVerticesToFringe( HeapNode prioritynode ) {
		// Get the vertex encapsulated by the heap node
		Vertex priorityvertex = ((FringeObject) prioritynode.getObject()).vertex;

		// Get the priority of the heap node
		double priority = prioritynode.getPriority();

		// The new priority of a heap node
		double fringepriority;

		// For each edge of the vertex ...
		// We can't use wgraph.getAdjacentVertices() as that will
		// not tell us what edge to use.
		try {
			for ( Edge e : wgraph.getEdges(priorityvertex) ) {
				WeightedEdge incidentedge = (WeightedEdge) e;

				// skip edge if graph is directed and the edge is an incoming edge
				if ( wgraph.isDirected() && incidentedge.getVertexB()==priorityvertex )
					continue;

				// ... get the vertex opposite to the priority vertex
				// meaning get the adjacent vertex
				Vertex adjacentvertex = incidentedge.getOppositeVertex( priorityvertex );

				// ... check if the adjacent vertex has been visited
				// If it has been visited, then proceed with the next edge
				if ( this.visited.contains( adjacentvertex )) continue;

				// Create a new DirectedWeightedEdge (!) for the target tree
				DirectedWeightedEdge newedge = new DirectedWeightedEdge(
						priorityvertex, adjacentvertex, incidentedge.getWeight() );

				// ... check if the adjacent vertex is already in the fringe
				// This is too slow ... (linear costs)
				//heapnode = (HeapNode) this.fringe.contains( adjacentvertex, heapnodeobjectcomparator );
				// This is better... (almost constant costs)
				HeapNode heapnode = this.fringeMap.get( adjacentvertex );

				// ... if it is not yet on the fringe, add it to the fringe
				if( heapnode == null ) {
					fringepriority = priority + incidentedge.getWeight();
					heapnode = new HeapNode( new FringeObject( adjacentvertex, newedge ), fringepriority );
					this.fringe.add( heapnode );
					this.fringeMap.put( adjacentvertex, heapnode );
				} else {
					// If it is already on the fringe, reassign its priority,
					// only if it will give it a "higher" priority.
					// Use the HeapNodeComparator to determine which is "higher".
					fringepriority = priority + incidentedge.getWeight();
					if ( comparator.compare( new HeapNode( adjacentvertex, fringepriority), heapnode ) < 0 ) {
						fringe.remove(heapnode);
						heapnode.setPriority(fringepriority);
						fringe.add(heapnode);
						// Also reassign the edge that is used to get the shortest path
						FringeObject fobject = (FringeObject) heapnode.getObject();
						fobject.edge = newedge;
					}
				}
			}
		} catch (NullPointerException npe) {}
	}
}

/**
 * An Object encapsulated in a HeapNode, which in turn is added to the fringe.
 * The classical algorithm only mentions of storing vertices in the fringe, but
 * it is programatically difficult to determine what edge to add to the
 * shortest path spanning tree when moving a vertex from the fringe to the tree.
 * It is therefore easier to store the edge along with the vertex in the fringe.
 *
 * The edge stored along with the vertex in the fringe is the
 * edge connecting the vertex that has been moved from the fringe to the tree
 * and the vertex adjacent to the vertex that has been moved from the fringe
 * and being added to the fringe.
 *
 */
class FringeObject 
{
	Vertex        vertex;
	DirectedWeightedEdge  edge;

	public FringeObject( Vertex vertex, DirectedWeightedEdge edge ) {
		this.vertex = vertex;
		this.edge = edge;
	}

	public String toString() {
		return "Vertex: " + vertex + "; Edge: " + edge;
	}
}
