package graph.algorithm;

import graph.*;
import util.*;
import java.util.*;

/**
 * A class using the A*-algorithm for quickly finding the shortest
 * path from a start vertex to a target vertex by means of an estimation
 * function that modifies the Dijkstra algorithm.
 * 
 * @author Ralf Vandenhouten
 * @version 2.0 2010-09-16
 */
public class ShortestPathDijkstraWithEstimator extends ShortestPathAlgorithm {

	private static final long serialVersionUID = 1L;

	/**
	 * List of vertices that has been added to the tree
	 */
	private HashSet<Vertex> visited;

	/**
	 * Heap of FringeObjects that are to be processed.
	 */
	private PriorityQueue<HeapNode> fringe;

	/**
	 * HashMap for fast detection of a vertex' heap node
	 */
	private HashMap<Vertex,HeapNode> fringeMap;

	/**
	 * Subgraph forming the shortest spanning tree.
	 */
	private WeightedGraph shortestpathtree;

	/**
	 * Comparator used to be compare priorities in the fringe.
	 */
	private HeapNodeComparator comparator;

	/**
	 * Estimator for distance to target
	 */
	private Estimator estimator;

	/**
	 * Target vertex to find
	 */
	private Vertex target = null;

	/**
	 * Creates an instance of ShortestPathAlgorithmDijkstra.
	 *
	 * @param wgraph  The WeightedGraph where a shortest path spanning tree will be determined.
	 * @param comparator  The HeapNodeComparator to be used to compare priorities of objects in the fringe/heap.
	 */
	public ShortestPathDijkstraWithEstimator( WeightedGraph wgraph, HeapNodeComparator comparator, Estimator estimator ) {
		super( wgraph );
		this.visited = new HashSet<Vertex>();
		this.comparator = comparator;
		this.fringe = new PriorityQueue<HeapNode>( wgraph.getVerticesCount(), new HeapNodeComparator( -1 ) );
		this.fringeMap = new HashMap<Vertex,HeapNode>();
		this.estimator = estimator;
	}

	/**
	 * Creates an instance of ShortestPathAlgorithmDijkstra using the default
	 * HeapNodeComparator.
	 *
	 * @param wgraph  The WeightedGraph where a shortest path spanning tree will be determined.
	 */
	public ShortestPathDijkstraWithEstimator( WeightedGraph wgraph, Estimator estimator ) {
		this( wgraph, new HeapNodeComparator(-1), estimator );
	}

	/*
	 * (non-Javadoc)
	 * @see graph.algorithm.ShortestPathAlgorithm#getShortestPath(graph.Vertex, graph.Vertex)
	 */
	public List<Vertex> getShortestPath( Vertex v1, Vertex v2 ) {
		this.target = v2;
		shortestpathtree = null;
		return super.getShortestPath(v1, v2);
	}

	/**
	 * Determines the shortest path from a given vertex to all other vertices
	 * that are in the same connected set as the given vertex in the weighted graph
	 * using Dijkstra's algorithm.
	 *
	 * @return  A WeightedGraph comprising of the shortest path spanning tree.
	 */
	public WeightedGraph shortestPath() {
		if ( startVertex == null )
			return null;

		// clear the graph.
		this.shortestpathtree = new WeightedGraphImpl( true );

		// Now add the vertex we are interested in to the fringe.
		HeapNode hn = new HeapNode( new EstimatorFringeObject( startVertex, null ), estimator.estimate(startVertex) );
		this.fringe.add( hn );
		this.fringeMap.put( startVertex, hn );

		// Continually process while there are vertices in the heap.
		while ( !this.fringe.isEmpty() ) {
			// Moves the highest priority node from the heap to the tree.
			if (moveToVisited())
				break;
		}

		// Clear the vectors
		this.visited.clear();
		this.fringe.clear();
		this.fringeMap.clear();

		return shortestpathtree;
	}

	/**
	 * Moves the vertex that has the highest priority in the heap
	 * from the fringe to the tree
	 * @return true if shortest path to target was found, otherwise false
	 */
	private boolean moveToVisited() {
		HeapNode  prioritynode;

		// Remove the node with highest priority from the fringe ...
		prioritynode = this.fringe.remove( );

		EstimatorFringeObject fringeobject = (EstimatorFringeObject) prioritynode.getObject();
		Vertex priorityvertex = fringeobject.vertex;

		this.fringeMap.remove( priorityvertex );

		// ... and add it to the tree.
		this.visited.add( priorityvertex );
		if( fringeobject.edge != null ) {
			try {
				this.shortestpathtree.addEdge( fringeobject.edge );
			}
			catch( Exception ex ) {
				ex.printStackTrace();
			}
		}

		if (priorityvertex == target)
			return true;

		// ... then move all the adjacent vertices of the vertex
		// we just moved to the tree and put them in the fringe.
		this.moveAdjacentVerticesToFringe( prioritynode );

		return false;
	}

	/**
	 * Gets all the adjacent vertices from unseen to the fringe.
	 * The parameter vertex must be a vertex that is being moved
	 * from the fringe to the tree. This method must only be called
	 * by the method moveToVisited().
	 *
	 * @param vertex  The vertex that is being moved from the fringe to the tree
	 * and whose adjacent vertices we want added to the fringe.
	 */
	private void moveAdjacentVerticesToFringe( HeapNode prioritynode ) {
		// Get the vertex encapsulated by the heap node
		Vertex    priorityvertex = ((EstimatorFringeObject) prioritynode.getObject()).vertex;

		// Get the priority of the heap node
		double    priority = prioritynode.getPriority() - estimator.estimate(priorityvertex);

		// The new priority of a heapnode
		double    fringepriority;

		// For each edge of the vertex ...
		// We can't use wgraph.getAdjacentVertices() as that will
		// not tell us what edge to use.
		try {
			for ( Edge edge : wgraph.getEdges(priorityvertex) ) {

				WeightedEdge incidentedge = (WeightedEdge) edge;

				// skip edge if graph is directed and the edge is an incoming edge
				if ( wgraph.isDirected() && incidentedge.getVertexB()==priorityvertex )
					continue;

				// ... get the vertex opposite to the priority vertex
				// meaning get the adjacent vertex
				Vertex adjacentvertex = incidentedge.getOppositeVertex( priorityvertex );

				// ... check if the adjacent vertex has been visited
				// If it has been visited, then proceed with the next edge
				if ( this.visited.contains( adjacentvertex )) continue;

				// ... check if the adjacent vertex is already in the fringe
				// This is too slow ... (linear costs)
				//heapnode = (HeapNode) this.fringe.contains( adjacentvertex, heapnodeobjectcomparator );
				// This is better... (almost constant costs)
				HeapNode heapnode = this.fringeMap.get( adjacentvertex );

				// Create a new DirectedWeightedEdge (!) for the target tree
				DirectedWeightedEdge newedge = new DirectedWeightedEdge(
						priorityvertex, adjacentvertex, incidentedge.getWeight() );

				fringepriority = priority + incidentedge.getWeight() + estimator.estimate(adjacentvertex);
				// ... if it is not yet on the fringe, add it to the fringe
				if( heapnode == null ) {
					heapnode = new HeapNode( new EstimatorFringeObject( adjacentvertex, newedge ), fringepriority );
					this.fringe.add( heapnode );
					this.fringeMap.put( adjacentvertex, heapnode );
				} else {
					// If it is already on the fringe, reassign its priority,
					// only if it will give it a "higher" priority.
					// Use the HeapNodeComparator to determine which is "higher".
					if( this.comparator.compare( new HeapNode( adjacentvertex, fringepriority), heapnode ) < 0 ) {
						fringe.remove(heapnode);
						heapnode.setPriority(fringepriority);
						fringe.add(heapnode);
						// Also reassign the edge that is used to get the shortest path
						EstimatorFringeObject fobject = (EstimatorFringeObject) heapnode.getObject();
						fobject.edge = newedge;
					}
				}
			}
		} catch (NullPointerException npe) {}
	}
}

/**
 * An Object encapsulated in a HeapNode, which in turn is added to the fringe.
 * The classical algorithm only mentions of storing vertices in the fringe, but
 * it is programatically difficult to determine what edge to add to the
 * shortest path spanning tree when moving a vertex from the fringe to the tree.
 * It is therefore easier to store the edge along with the vertex in the fringe.
 *
 * The edge stored along with the vertex in the fringe is the
 * edge connecting the vertex that has been moved from the fringe to the tree
 * and the vertex adjacent to the vertex that has been moved from the fringe
 * and being added to the fringe.
 *
 */
class EstimatorFringeObject 
{
	Vertex        vertex;
	DirectedWeightedEdge  edge;

	public EstimatorFringeObject( Vertex vertex, DirectedWeightedEdge edge ) {
		this.vertex = vertex;
		this.edge = edge;
	}

	public String toString() {
		return "Vertex: " + vertex + "; Edge: " + edge;
	}
}
