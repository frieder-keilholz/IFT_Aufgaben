package graph.algorithm;

import graph.*;
import java.util.*;

/**
 * Class for coloring a graph using the approximating algorithm of Johnson.
 * Extends the abstract GraphColoring class.
 *
 * @author Ralf Vandenhouten
 * @version 2.0 2010-09-16
 */

public class JohnsonColoring extends GraphColoring {

	private static final long serialVersionUID = 2L;

	/**
     * Constructor for JohnsonColoring objects
     */
    public JohnsonColoring( Graph graph ) {
        super( graph );
    }

    /**
     * Coloring method using the Johnson algorithm. The algorithm has a
     * complexity of approximately n*n where n is the number of vertices in the
     * graph.
     *
     * @param maxNumOfColors The maximum number of colors to be used for coloring.
     *          If that is not enough, a NotEnoughColorsException is thrown.
     *
     * @exception NotEnoughColorsException
     * @return The HashMap containing the color mapping of the vertices.
     */
    @SuppressWarnings("unchecked")
	public Map<Vertex,Integer> coloring( int maxNumOfColors )
    throws NotEnoughColorsException {
        int color=0;
        HashSet<Vertex> U, W = new HashSet<Vertex>( graph.getVertices() );

        do {
            U = (HashSet<Vertex>)W.clone();
            color++;
            if ( color > maxNumOfColors )
                throw new NotEnoughColorsException(
                    "Algorithm needs more than "+maxNumOfColors+" colors.");
            int currentColor = color;
            while ( !U.isEmpty() ) {
                // Find u in U with minimum degree in the subgraph induced by U
                int minDegree = Integer.MAX_VALUE;
                Vertex minu = null;
                HashSet<Vertex> minNu = null;
                for (Vertex u : U) {
                    // Determine set of neighbors of u in U by intersection
                    HashSet<Vertex> Nu = new HashSet<Vertex>(graph.getAdjacentVertices(u));
                    Nu.retainAll(U);
                    // Determine new minDegree
                    if ( Nu.size() < minDegree ) {
                        minDegree = Nu.size();
                        minu = u;
                        minNu = Nu;
                    }
                }
                // Paint the vertex u with minimum degree in U
                colorMap.put( minu, currentColor );
                // Remove the vertex from U and W
                U.remove( minu );
                U.removeAll( minNu );
                W.remove( minu );
            }
        } while ( !W.isEmpty() );
        return this.colorMap;
    }
}