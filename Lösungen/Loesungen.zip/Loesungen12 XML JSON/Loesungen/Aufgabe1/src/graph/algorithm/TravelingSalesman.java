package graph.algorithm;

import graph.*;
import java.util.*;

/**
 * This is a class for solving the traveling salesman problem for a given
 * complete graph.
 *
 * @author Ralf Vandenhouten
 * @version 1.0 2002-10-30
 */
public class TravelingSalesman {

	/**
	 * The WeightedGraph object that the algorithm uses to determine
	 * the traveling salesman path.
	 */
	WeightedGraph   wgraph;

	/**
	 * Number of vertices in the network.
	 */
	int nvertices;

	/**
	 * Array storing the vertices linearly.
	 */
	Vertex[] vertex;

	/**
	 * HashMap storing the indices of the vertices in the above array vertex.
	 */
	HashMap<Vertex,Integer> vertIndex;

	/**
	 * Adjacency matrix where the entry [i][j] contains the length of the edge
	 * from vertex i to vertex j.
	 */
	double distance[][];

	/**
	 * The traveling salesman path as a List of vertices.
	 */
	List<Vertex> path;

	/**
	 * Constructor for the TravelingSalesman class.
	 *
	 * @param wgraph The weighted graph where the optimum traveling salesman path
	 *   is to be found. Note that wgraph <b>must</b> be a complete graph, i.e.
	 *   each vertex must be connected to each other vertex.
	 */
	public TravelingSalesman( WeightedGraph wgraph ) {
		this.wgraph = wgraph;
		int i = 0, j;
		nvertices = wgraph.getVerticesCount();
		vertex = new Vertex[nvertices];
		vertIndex = new HashMap<Vertex,Integer>(nvertices*3/2);
		distance = new double[nvertices][nvertices];

		// Initializing the data structures
		for (Iterator<Vertex> it = wgraph.getVerticesIterator(); it.hasNext(); ) {
			Vertex v = it.next();
			vertIndex.put( v, new Integer(i) );
			vertex[i++] = v;
		}
		for (i=0; i<nvertices; i++)
			for (j=0; j<nvertices; j++)
				distance[i][j] = Double.POSITIVE_INFINITY;
		for (Iterator<Edge> it = wgraph.getAllEdges().iterator(); it.hasNext(); ) {
			WeightedEdge e = (WeightedEdge)it.next();
			double weight = e.getWeight();
			i = vertIndex.get(e.getVertexA());
			j = vertIndex.get(e.getVertexB());
			distance[i][j] = weight;
			distance[j][i] = weight;
		}
	}

	/**
	 * Method for solving the Traveling Salesman problem exactly by back tracking.
	 * The complexity is exponential, i.e. proportional to exp(n) where n is the
	 * number of vertices.
	 *
	 * @return The List containing the vertices of the optimimum traveling
	 *         salesman path in the right order.
	 */
	public List<Vertex> travelingSalesmanPathBackTrack() {
		path = new ArrayList<Vertex>();
		int pathArray[] = new int[nvertices]; // keeps the path as a stack
		int minPath[] = new int[nvertices];
		boolean visited[] = new boolean[nvertices];
		double length[] = new double[nvertices];
		double minlength=Double.POSITIVE_INFINITY;
		int i;

		pathArray[0] = 0;
		pathArray[1] = 0;
		int index = 1;
		while ( index > 0 ) {
			if ( pathArray[index] > 0 )
				visited[pathArray[index]] = false;
			// next try on level index
			do {
				pathArray[index]++;
				if ( pathArray[index] >= nvertices )
					break;
			} while ( visited[pathArray[index]] );
			if ( pathArray[index] < nvertices ) {
				visited[pathArray[index]] = true;
				length[index] = distance[pathArray[index-1]][pathArray[index]]
				                                             + length[index-1];
				if ( index == nvertices-1 ) { // all vertices travelled
					double d = length[index] +
					distance[pathArray[index]][pathArray[0]];
					if ( d < minlength ) { // new shortest path found
						minlength = d;
						// copy current path to minPath
						for (i=0; i<nvertices; i++)
							minPath[i] = pathArray[i];
					}
					// go back
					visited[pathArray[index]] = false;
					pathArray[index] = 0; // reset pointer for this level
					index--;
				} else { // try the next level
					index++;
				}
			} else { // no further vertex => track back
				pathArray[index] = 0;
				index--;
			}
		}
		// copy pathArray to path
		for (i=0; i<nvertices; i++)
			path.add( vertex[minPath[i]] );
		return path;
	}

	/**
	 * Method for finding an approximate solution of the Traveling Salesman
	 * problem in polynomial time for graphs that meet the triangle inequation
	 * for each triple of edges.
	 * The algorithm asymptotically asserts that the path found is not longer
	 * than twice as long as the optimum solution although the algorithm is much
	 * faster than back tracking for large graphs.
	 * The complexity is of the order O(n*n*n) where n is the number of vertices.
	 *
	 * @return The List containing the vertices of the traveling salesman path
	 * in the right order.
	 */
	public List<Vertex> travelingSalesmanPathApproximation() {
		path = new ArrayList<Vertex>();
		@SuppressWarnings("unchecked")
		List<Vertex> conjugateList = (List<Vertex>)((ArrayList<Vertex>)wgraph.getVertices()).clone();
		int i, j, vi, vj, imin=-1, jmin=-1, vjmin=-1;
		double mindist;
		// Initializing the two vertex lists
		path.add( 0, vertex[0] );
		conjugateList.remove( vertex[0] );

		while (path.size() < nvertices) {
			mindist = Double.POSITIVE_INFINITY;
			// look for the shortest edge from any vertex already in the path
			// to any new vertex
			for (i=0; i<path.size(); i++)
				for (j=0; j<conjugateList.size(); j++) {
					vi = vertIndex.get(path.get(i));
					vj = vertIndex.get(conjugateList.get(j));
					if (distance[vi][vj] < mindist) {
						mindist = distance[vi][vj];
						imin = i; jmin = j;
						vjmin = vj;
					}
				}
			// put the vertex found into the path list and remove it from the
			// conjugateList
			path.add(imin, vertex[vjmin]);
			conjugateList.remove(jmin);
		}
		return path;
	}

	/**
	 * Method that computes the path length of the traveling salesman solution.
	 *
	 * @return The closed path length of the traveling salesman solution.
	 */
	public double getPathLength() {
		int vi, vj;
		double l = 0.0;
		for (int i=0; i<path.size(); i++) {
			vi = vertIndex.get(path.get(i));
			vj = vertIndex.get(path.get((i+1)%path.size()));
			l += distance[vi][vj];
		}
		return l;
	}
}
