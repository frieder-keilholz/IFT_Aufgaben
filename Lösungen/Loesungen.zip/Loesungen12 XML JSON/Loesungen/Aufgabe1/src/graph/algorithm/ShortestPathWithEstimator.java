package graph.algorithm;

import graph.*;
import java.util.*;

/**
 * A class using the iterative A*-algorithm for quickly finding the shortest
 * path from a start vertex to a target vertex by means of an estimation
 * function.
 * 
 * @author Ralf Vandenhouten
 * @version 2.0 2010-09-16
 */
public class ShortestPathWithEstimator {
	/**
	 * The WeightedGraph object that the algorithm uses to determine
	 * the shortest path.
	 */
	private WeightedGraph   wgraph;
	/**
	 * Estimator object that estimates the distance of a vertex to the target
	 * vertex.
	 */
	private Estimator estimator;
	/**
	 * Vector storing the distances of the vertices from the start vertex
	 * in the current path
	 */
	private Vector<Double> distance;
	/**
	 * Start vertex
	 */
	private Vertex startVertex;
	/**
	 * Target vertex of the shortest path search
	 */
	private Vertex targetVertex;
	/**
	 * List containing the vertices of the shortest path
	 */
	private List<Vertex> shortestpath;

	/**
	 * Creates an instance of ShortestPathAlgorithmEstimator.
	 *
	 * @param wgraph  The WeightedGraph where a shortest path will
	 *                be determined
	 * @param estimator The Estimator object that estimates the distance of each
	 *    vertex from the target vertex. The estimated distance must be lower or
	 *    equal the actual shortest path distance.
	 */
	public ShortestPathWithEstimator( WeightedGraph wgraph, Estimator estimator ) {
		this.wgraph = wgraph;
		this.estimator = estimator;
	}

	/**
	 * Determines the shortest path from a given start vertex to the target vertex
	 * using the iterative Estimator-based A*-algorithm for optimizing the search.
	 *
	 * @param start The start vertex for the search
	 * @param target The target vertex of the search
	 * @return  A List containing the vertices that the shortest path from the
	 *          start vertex to the target vertex consists of.
	 */
	public List<Vertex> getShortestPath( Vertex start, Vertex target ) {
		if ( start == null || target == null )
			return null;
		startVertex = start;
		targetVertex = target;
		int i=0;
		double dj, b, bound, boundNew;
		Vertex vi, vj;
		boolean found = false;
		Stack<Vertex> vertexStack = new Stack<Vertex>(); // stack for vertices
		Stack<Iterator<Edge>> edgesStack = new Stack<Iterator<Edge>>();  // stack for edge iterators of the vertices
		distance = new Vector<Double>();

		bound = estimator.estimate( start );
		// outer iterative loop increasing the bound values
		OUTER_LOOP:
			while ( !found && bound < Double.POSITIVE_INFINITY ) {
				System.out.println( "Bound: " + bound );
				vertexStack.push( start );
				edgesStack.push( wgraph.getEdges(start).iterator() );
				distance.clear();
				distance.add( 0, 0.0 );
				i=0;
				boundNew = Double.POSITIVE_INFINITY;
				// inner loop doing the shortest path search
				while ( !found && !vertexStack.isEmpty() ) {
					vi = (Vertex)vertexStack.peek();
					Iterator<Edge> it = edgesStack.peek();
					if ( vi != target ) {
						if ( it.hasNext() ) {
							WeightedEdge e = (WeightedEdge)it.next();
							vj = e.getOppositeVertex( vi );
							dj = distance.get(i) + e.getWeight();
							b = estimator.estimate( vj ) + dj;
							if ( b > bound ) {
								boundNew = Math.min( b, boundNew );
							} else {
								vertexStack.push( vj );
								edgesStack.push( wgraph.getEdges( vj ).iterator() );
								i++;
								distance.add( i, dj );
							}
						} else {
							vertexStack.pop();
							edgesStack.pop();
							distance.remove( i-- );
						}
					} else {
						found = true;
						break OUTER_LOOP;
					}
				}
				bound = boundNew;
			}

		if ( !found ) {
			shortestpath = null;
		} else {
			shortestpath = new ArrayList<Vertex>(vertexStack.size());
			while ( !vertexStack.isEmpty() )
				shortestpath.add( 0, vertexStack.pop() );
		}
		return shortestpath;
	}

	/**
	 * Compute the distance between two vertices in the shortest path
	 *
	 * @param v1 The start vertex
	 * @param v2 The target vertex
	 * @return The distance between v1 and v2 in the shortest path spanning tree
	 *         if v2 is reachable from v1, otherwise Double.POSITIVE_INFINITY
	 *         is returned.
	 */
	public double getDistance( Vertex v1, Vertex v2 ) {
		if ( shortestpath==null || v1!=startVertex || v2!=targetVertex )
			shortestpath = getShortestPath( v1, v2 );
		return distance.lastElement();
	}
}
