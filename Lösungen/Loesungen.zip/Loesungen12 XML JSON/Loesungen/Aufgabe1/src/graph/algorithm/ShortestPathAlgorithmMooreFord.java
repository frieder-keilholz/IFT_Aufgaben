package graph.algorithm;

import java.util.*;
import graph.*;

/**
 * A concrete implementation of ShortestPathAlgorithm using the method
 * of E.F. Moore and L.R. Ford.
 * Note that the Moore-Ford method can only be applied to graphs without a
 * cycle that has a negative length.
 *
 * @author Ralf Vandenhouten
 * @version 2.0 2010-09-16
 */
public class ShortestPathAlgorithmMooreFord extends ShortestPathAlgorithm {

	private static final long serialVersionUID = 2L;

	/**
	 * Map containing the predecessors of the vertices in the shortest path tree
	 */
	private Map<Vertex,DirectedWeightedEdge> predecessor;

	/**
	 * Map mapping vertices to their distances from the start vertex
	 */
	private Map<Vertex,Double> distance;

	/**
	 * Subgraph forming the shortest spanning tree.
	 */
	private WeightedGraph shortestpathtree;

	/**
	 * Creates an instance of ShortestPathAlgorithmMooreFord.
	 *
	 * @param wgraph  The WeightedGraph where a shortest path spanning tree will
	 *                be determined.
	 */
	public ShortestPathAlgorithmMooreFord( WeightedGraph wgraph ) {
		super( wgraph );
		this.predecessor = new HashMap<Vertex,DirectedWeightedEdge>();
		this.distance = new HashMap<Vertex,Double>();
	}

	/**
	 * Determines the shortest path from a given vertex to all other vertices
	 * that are in the same connected set as the given vertex in the weighted graph
	 * using the algorithm of Moore and Ford.
	 *
	 * @return  A WeightedGraph comprising of the shortest path spanning tree.
	 */
	public WeightedGraph shortestPath() {
		double di, dj;
		Vertex vi, vj;
		if ( startVertex == null )
			return null;

		// Initializing
		this.shortestpathtree = new WeightedGraphImpl( true );
		for ( Vertex v : wgraph.getVertices() )
			distance.put( v, Double.POSITIVE_INFINITY );

		distance.put( startVertex, new Double(0.0) );
		Queue<Vertex> queue = new ArrayDeque<Vertex>();

		// generate the shortest path tree
		queue.add( startVertex );
		while ( !queue.isEmpty() ) {
			try {
				vi = queue.remove();
				di = distance.get( vi );
				for ( Edge edge : wgraph.getEdges( vi ) ) {
					WeightedEdge e = (WeightedEdge) edge;
					// skip incoming edges
					if ( wgraph.isDirected() && e.getVertexB()== vi )
						continue;
					vj = e.getOppositeVertex( vi );
					dj = distance.get( vj );
					if ( di + e.getWeight() < dj ) {
						distance.put( vj, di + e.getWeight() );
						predecessor.put( vj,
								new DirectedWeightedEdge( vi, vj, e.getWeight() ) );
						if ( !queue.contains( vj ) ) // TODO: This could be more efficient!
							queue.add( vj );
					}
				}
			} catch (Exception e) { e.printStackTrace(); }
		}

		// insert the edges into the shortest path tree
		for ( Edge edge : predecessor.values() ) {
			try {
				shortestpathtree.addEdge( edge );
			} catch (Exception e) { e.printStackTrace(); }
		}
		return shortestpathtree;
	}

	/**
	 * Compute the distance between two vertices in the shortest path spanning
	 * tree.
	 *
	 * @param v1 The start vertex
	 * @param v2 The target vertex
	 * @return The distance between v1 and v2 in the shortest path spanning tree
	 *         if v2 is reachable from v1, otherwise Double.POSITIVE_INFINITY
	 *         is returned.
	 */
	public double getDistance( Vertex v1, Vertex v2 ) {
		if ( shortestpathtree==null || v1!=startVertex )
			shortestpathtree = shortestPath( v1 );
		return distance.get( v2 );
	}

	/**
	 * Method that computes the longest distance of any vertex from the start
	 * vertex of the shortest path spanning tree.
	 *
	 * @param v1 The start vertex
	 * @return The longest distance between v1 and any other vertex in the
	 *         shortest path spanning tree.
	 */
	public double getLongestDistance( Vertex v1 ) {
		if ( shortestpathtree==null || v1!=startVertex )
			shortestpathtree = shortestPath( v1 );
		double d, max = Double.NEGATIVE_INFINITY;
		for ( Vertex v : wgraph.getVertices()) {
			d = distance.get( v );
			if ( d > max && d != Double.POSITIVE_INFINITY )
				max = d;
		}
		return max;
	}
}
