package graph.algorithm;

import graph.*;

import java.util.*;

/**
 * A concrete implementation of ShortestPathAlgorithm using the method
 * of R. Floyd. The algorithm determines the shortest paths between all pairs
 * of vertices and stores the distances and the predecessor lists in two
 * matrices.
 * 
 * @author Ralf Vandenhouten
 * @version 2.0 2010-09-16
 */
public class ShortestPathAlgorithmFloyd extends ShortestPathAlgorithm {

	private static final long serialVersionUID = 2L;

	/**
	 * Number of vertices in the network.
	 */
	private int nvertices;

	/**
	 * Array storing the vertices linearly.
	 */
	private Vertex[] vertex;

	/**
	 * HashMap storing the indices of the vertices in the above array vertex.
	 */
	private HashMap<Vertex,Integer> vertIndex;

	/**
	 * Arrays of lists containing the adjacent vertices.
	 */
	private ArrayList<Vertex>[] successors;

	/**
	 * Matrix where the entry [i][j] contains the shortest distance from vertex i
	 * to vertex j.
	 */
	private double distance[][];

	/**
	 * Matrix where the entry [i][j] contains the index of the predecessor of
	 * vertex j in the shortest path spanning tree of vertex i.
	 */
	private int shortestPaths[][];

	/**
	 * Creates an instance of ShortestPathAlgorithmMooreFord.
	 *
	 * @param wgraph  The WeightedGraph where a shortest path spanning tree will
	 *                be determined.
	 */
	@SuppressWarnings("unchecked")
	public ShortestPathAlgorithmFloyd( WeightedGraph wgraph ) {
		super( wgraph );
		int i = 0;
		nvertices = wgraph.getVerticesCount();
		vertex = new Vertex[nvertices];
		vertIndex = new HashMap<Vertex,Integer>(nvertices*3/2);
		successors = (ArrayList<Vertex>[]) new ArrayList<?>[nvertices];

		// Initializing the data structures
		for (Iterator<Vertex> it = wgraph.getVerticesIterator(); it.hasNext(); ) {
			Vertex v = it.next();
			vertIndex.put( v, i );
			successors[i] = 
				(ArrayList<Vertex>)((ArrayList<Vertex>)wgraph.getOutgoingAdjacentVertices( v )).clone();
			vertex[i++] = v;
		}
	}

	/**
	 * Determines the shortest path from a given vertex to all other vertices
	 * that are in the same connected set as the given vertex in the weighted graph
	 * using the algorithm of R. Floyd.
	 *
	 * @return  A WeightedGraph comprising of the shortest path spanning tree.
	 */
	public WeightedGraph shortestPath() {
		int i, j, k;

		// Initialize matrices
		distance = new double[nvertices][nvertices];
		shortestPaths = new int[nvertices][nvertices];
		for (i=0; i<nvertices; i++)
			for (j=0; j<nvertices; j++) {
				if ( i==j )
					distance[i][j] = 0.0;
				else
					distance[i][j] = Double.POSITIVE_INFINITY;
				shortestPaths[i][j] = -1;
			}
		for ( Edge edge : wgraph.getAllEdges() ) {
			WeightedEdge e = (WeightedEdge) edge;
			int i1 = vertIndex.get(e.getVertexA());
			int i2 = vertIndex.get(e.getVertexB());
			distance[i1][i2] = e.getWeight();
			shortestPaths[i1][i2] = i1;
			if ( !wgraph.isDirected() ) {
				distance[i2][i1] = distance[i1][i2];
				shortestPaths[i2][i1] = i2;
			}
		}
		// Floyd algorithm
		for (j=0; j<nvertices; j++) {
			for (i=0; i<nvertices; i++)
				for (k=0; k<nvertices; k++)
					if ( distance[i][k] > distance[i][j] + distance[j][k] ) {
						distance[i][k] = distance[i][j] + distance[j][k];
						shortestPaths[i][k] = shortestPaths[j][k];
					}
		}

		if ( startVertex == null )
			return null;
		return shortestPath( startVertex );
	}

	/**
	 * Method that computes the shortest path spanning tree for the given vertex.
	 *
	 * @param from The root vertex of the shortest path spanning tree.
	 * @return A new WeightedGraph that represents the shortest path spanning
	 * tree of the original WeightedGraph.
	 */
	public WeightedGraph shortestPath( Vertex from ) {
		if ( shortestPaths==null || distance==null )
			shortestPath();
		startVertex = from;
		int index = vertIndex.get( from );
		// Initializing
		this.shortestpathtree = new WeightedGraphImpl( true );
		for (int i=0; i<nvertices; i++) {
			if ( i==index )
				continue;
			try {
				int pred = shortestPaths[index][i];
				shortestpathtree.addEdge(
						new DirectedWeightedEdge( vertex[pred], vertex[i],
								distance[index][i]-distance[index][pred] ));
			}
			catch (Exception e) { e.printStackTrace(); }
		}
		return shortestpathtree;
	}

	/**
	 * This method returns the shortest path between two vertices as a list of the
	 * vertices the path consists of.
	 *
	 * @param v1 The start vertex of the path
	 * @param v2 The target vertex of the path
	 * @return The List object containing the vertices of the path.
	 */
	public List<Vertex> getShortestPath( Vertex v1, Vertex v2 ) {
		if ( shortestPaths==null || distance==null )
			shortestPath();
		List<Vertex> vlist = new ArrayList<Vertex>(nvertices);
		int index1 = vertIndex.get( v1 );
		int index2 = vertIndex.get( v2 );
		// Generate the path by stepping backward through the predecessor list
		int pred = index2;
		while ( pred != index1 && pred != -1 ) {
			vlist.add(0, vertex[pred]);
			pred = shortestPaths[index1][pred];
		}
		if ( pred == index1 ) {
			vlist.add( 0, vertex[pred] );
			return vlist;
		} else {
			return null; // something is wrong...
		}
	}

	/**
	 * Compute the distance between two vertices in the shortest path spanning
	 * tree.
	 *
	 * @param v1 The start vertex
	 * @param v2 The target vertex
	 * @return The distance between v1 and v2 in the shortest path spanning tree
	 *         if v2 is reachable from v1, otherwise Double.POSITIVE_INFINITY
	 *         is returned.
	 */
	public double getDistance( Vertex v1, Vertex v2 ) {
		if ( shortestPaths==null || distance==null )
			shortestPath();
		int index1 = vertIndex.get( v1 );
		int index2 = vertIndex.get( v2 );
		return distance[index1][index2];
	}

	/**
	 * Method that computes the longest distance of any vertex from the start
	 * vertex of the shortest path spanning tree.
	 *
	 * @param v1 The start vertex
	 * @return The longest distance between v1 and any other vertex in the
	 *         shortest path spanning tree.
	 */
	public double getLongestDistance( Vertex v1 ) {
		if ( shortestPaths==null || distance==null )
			shortestPath();
		double d, max = Double.NEGATIVE_INFINITY;
		int index = ((Integer)vertIndex.get( v1 )).intValue();
		for (int i=0; i<nvertices; i++) {
			d  = distance[index][i];
			if ( d > max && d!=Double.POSITIVE_INFINITY )
				max = d;
		}
		return max;
	}

	/**
	 * Method that computes the routing table corresponding to a shortest path
	 * spanning tree as a map of target vertices to neighbor vertices.
	 *
	 * @param v The node of which the routing table is of interest.
	 * @return A Map object that maps a target vertex of the spanning tree to the
	 *    neighboring node of the vertex v that is used for routing to this
	 *    target.
	 */
	public Map<Vertex,Vertex> getRoutingTable( Vertex v ) {
		if ( shortestPaths==null || distance==null )
			shortestPath();
		int index = vertIndex.get( v );
		Map<Vertex,Vertex> routingMap = new HashMap<Vertex,Vertex>();
		for (int i=0; i<nvertices; i++) {
			if ( i==index )
				continue;
			int pred = i;
			while ( shortestPaths[index][pred]!=index &&
					shortestPaths[index][pred]!=-1 ) {
				pred = shortestPaths[index][pred];
			}
			if ( shortestPaths[index][pred] == index )
				routingMap.put( vertex[i], vertex[pred] );
		}
		return routingMap;
	}

	/**
	 * String output of the two matrices distance and shortestPaths.
	 */
	public String toString() {
		String result = "Distance matrix:\n";
		for (int i=0; i<nvertices; i++) {
			for (int j=0; j<nvertices; j++)
				result += distance[i][j] + " ";
			result += "\n";
		}
		result += "Shortest path matrix:\n";
		for (int i=0; i<nvertices; i++) {
			for (int j=0; j<nvertices; j++)
				result += shortestPaths[i][j] + " ";
			result += "\n";
		}
		return result;
	}
}
