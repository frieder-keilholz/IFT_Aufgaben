package graph;

import java.io.*;
import java.util.*;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;

/**
 * <p>Title: Klassen zur Realisierung von Graphen</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2016</p>
 * <p>Company: TH Wildau</p>
 * @author Ralf Vandenhouten
 * @version 1.1
 */

public class GraphML extends DefaultHandler {
    private StringBuffer textBuffer;
    static private Graph graph;
    private HashMap<String, Vertex> nodes;
    private Vertex currentNode = null;
    
    public Graph readGraphFromGraphMLFile(String filename) throws Exception
    {
        // Use an instance of ourselves as the SAX event handler
        DefaultHandler handler = new GraphML();

        // Use the default (non-validating) parser
        SAXParserFactory factory = SAXParserFactory.newInstance();
        try {
            // Parse the input
            SAXParser saxParser = factory.newSAXParser();
            saxParser.parse( new File(filename), handler);

        } catch (Throwable t) {
            t.printStackTrace();
        }
        return graph;
    }

    //===========================================================
    // SAX DocumentHandler methods
    //===========================================================

    public void startDocument()
    throws SAXException
    {
        nodes=new HashMap<String, Vertex>();
    }

    public void endDocument()
    throws SAXException
    {

    }

    public void startElement(String namespaceURI,
            String sName, // simple name
            String qName, // qualified name
            Attributes attrs)
    throws SAXException
    {
        Vertex temp;
        String eName = sName; // element name
        if ("".equals(eName)) eName = qName; // not namespaceAware
        if(eName.equals("graph"))
        {
            if (attrs != null)
            {
                for (int i = 0; i < attrs.getLength(); i++)
                {
                    String aName = attrs.getLocalName(i); // Attr name
                    if ("".equals(aName)) aName = attrs.getQName(i);
                    if(aName.equals("edgedefault"))
                    {
                        if(attrs.getValue(i).equals("directed"))
                        {
                            graph = new GraphImpl(true);
                        }
                        else
                        {
                            graph = new GraphImpl(false);
                        }
                    }
                }
            }
        }
        if(eName.equals("node"))
        {
            if (attrs != null)
            {
                for (int i = 0; i < attrs.getLength(); i++)
                {
                    String aName = attrs.getLocalName(i); // Attr name
                    if ("".equals(aName)) aName = attrs.getQName(i);
                    if(aName.equals("id"))
                    {
                        temp=new Vertex(attrs.getValue(i));
                        // Knoten in Hashmap speichern, um bei Kantenerzeugung schnellen
                        // Zugriff zu haben
                        nodes.put(attrs.getValue(i),temp);
                        currentNode = temp;
                        try {graph.add(temp);}
                        catch(Exception e )
                        {
                            System.err.println(e.toString());
                        }
                    }
                }
            }
        }
        if(eName.equals("edge"))
        {
            Vertex source=null, target=null;

            if (attrs != null)
            {
                for (int i = 0; i < attrs.getLength(); i++)
                {
                    String aName = attrs.getLocalName(i); // Attr name
                    if ("".equals(aName))
                        aName = attrs.getQName(i);
                    if(aName.equals("source"))
                    {
                        source = nodes.get(attrs.getValue(i));
                    }
                    else if(aName.equals("target"))
                    {
                        target = nodes.get(attrs.getValue(i));
                    }
                }
                try {graph.addEdge(source, target);}
                catch(Exception e )
                {
                    System.err.println(e.toString());
                }
            }
        }
    }

    public void endElement(String namespaceURI,
            String sName, // simple name
            String qName  // qualified name
    ) throws SAXException
    {
        String eName = sName; // element name
        if ("".equals(eName)) eName = qName; // not namespaceAware
        if (eName.equals("y:NodeLabel") && currentNode!=null) {
            currentNode.setString(textBuffer.toString().trim());
            textBuffer = null;
        }
        else if (eName.equals("node"))
            currentNode = null;
    }

    public void characters(char buf[], int offset, int len)
    throws SAXException
    {
        String s = new String(buf, offset, len);
        if (textBuffer == null) {
            textBuffer = new StringBuffer(s);
        } else {
            textBuffer.append(s);
        }
    }

}