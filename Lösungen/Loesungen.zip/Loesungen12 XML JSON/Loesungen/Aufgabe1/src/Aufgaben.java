import graph.Graph;
import graph.GraphML;

public class Aufgaben {

  public static void main(String[] args) throws Exception {
      GraphML test = new GraphML();
      Graph graph = 
    	  	test.readGraphFromGraphMLFile("test2.graphml");
      System.out.println(graph);
  }
}

