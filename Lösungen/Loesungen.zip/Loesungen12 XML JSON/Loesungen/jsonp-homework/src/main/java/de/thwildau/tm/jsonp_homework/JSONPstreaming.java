package de.thwildau.tm.jsonp_homework;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import javax.json.Json;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

/**
 * Demo application for JSON-P streaming. The user can type in the name of a country and gets
 * the name of its capital as a response which is retrieved from a JSON file on the web.
 * 
 * @author Ralf Vandenhouten
 */
public class JSONPstreaming 
{
  public static void main( String[] args ) throws IOException
  {
    String countryName = "France";
    try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
      System.out.println("Which country are you interested in?");
      countryName = reader.readLine().trim();
    } catch (Exception e) {
    	System.err.println("Could not open reader\n" + e);
	}
    
    //1. Create a streaming parser from an InputStream
    URL url = new URL("http://restcountries.eu/rest/v1/all");
    try (InputStream is = url.openStream();
    JsonParser parser = Json.createParser(is)) {
      boolean foundCapital = false;
      boolean foundCountry = false;
      boolean inTranslations = false;
      String country = null;
      String capital = null;
      //2. Keep advancing the parser
      //until it finds the desired capital
      while (parser.hasNext() && !foundCapital) {
        Event e = parser.next();
        if (inTranslations) {
          System.out.println("If in translations path");
          if (e == Event.END_OBJECT) {
            inTranslations = false;
          } else if (e == Event.KEY_NAME) {
            if (parser.next() != Event.VALUE_NULL)
              country = parser.getString();
            if (countryName.equals(country)) {
              foundCountry = true;
              if (capital != null) {
                // no need to parse the rest of doc
                foundCapital = true;
                System.out.println("The capital of " + countryName + " is " + capital + ".");
              }
            }
          }
          continue;
        }
        if (e == Event.KEY_NAME) {
          switch (parser.getString()) {
            // is the parser on a pair
            // whose key is 'name' and
            // value is 'France'?
            case "name":
              capital = null;
              parser.next();
              country = parser.getString();
              if (country.equals(countryName)) {
                foundCountry = true;
              }
              break;
            case "capital":
              // parser is on the 'France' key/value
              // just advance the parser one step
              parser.next();
              // and get the actual value!
              capital = parser.getString();
              if (foundCountry) {
                // no need to parse the rest of doc
                foundCapital = true;
                System.out.println("The capital of " + countryName + " is " + capital + ".");
              }
              break;
            case "translations":
              if (!foundCountry)
                inTranslations = true;
              break;
          }
        }
      }
    }  
  }
}
