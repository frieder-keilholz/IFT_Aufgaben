import graph.*;

public class Aufgabe4 {

	public Aufgabe4() throws Exception {
		Tree    tree = new TreeImpl(false); // not directed
		Vertex  v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11;

		v1 = new Vertex( "1" );
		v2 = new Vertex( "2" );
		v3 = new Vertex( "3" );
		v4 = new Vertex( "4" );
		v5 = new Vertex( "5" );
		v6 = new Vertex( "6" );
		v7 = new Vertex( "7" );
		v8 = new Vertex( "8" );
		v9 = new Vertex( "9" );
		v10 = new Vertex( "10" );
		v11 = new Vertex( "11" );

		tree.addNode( null, v1 );

		tree.addNode( v1, v2 );
		tree.addNode( v1, v3 );
		tree.addNode( v1, v4 );

		tree.addNode( v2, v5 );
		tree.addNode( v2, v6 );

		tree.addNode( v3, v7 );

		tree.addNode( v7, v8 );
		tree.addNode( v7, v9 );
		tree.addNode( v7, v10 );
		tree.addNode( v7, v11 );

		// Teste Basisoperationen des Graphen
		System.out.println(tree);
		System.out.println("Ist v3 Nachbar von v1? " + tree.haveCommonEdge(v1, v3));
		System.out.println("Ist v7 Nachbar von v1? " + tree.haveCommonEdge(v1, v7));
		System.out.println("Nachbarn von v2: " + tree.getAdjacentVertices(v2));
		System.out.println("Grad von v2: " + tree.getDegree(v2));
		System.out.println("Parent von v11: " + tree.getParent(v11));
		System.out.println("Ist v7 ein Blatt? " + tree.isLeaf(v7));
		System.out.println("Ist v10 ein Blatt? " + tree.isLeaf(v10));
	}

	public static void main(String[] args) throws Exception {
		@SuppressWarnings("unused")
		Aufgabe4 test = new Aufgabe4();
	}
}
