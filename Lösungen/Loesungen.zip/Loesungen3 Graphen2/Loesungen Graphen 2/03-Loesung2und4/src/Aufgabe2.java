import graph.*;
import graph.algorithm.*;

public class Aufgabe2 {
	Vertex  v1, v2, v3, v4, v5, v6;
	Graph   graph;

	public Aufgabe2() throws Exception {

		graph = new GraphAdMatrix(true);

		// Generiere den Graphen aus Aufgabe 1
		v1 = new Vertex( "1" );
		v2 = new Vertex( "2" );
		v3 = new Vertex( "3" );
		v4 = new Vertex( "4" );
		v5 = new Vertex( "5" );
		v6 = new Vertex( "6" );

		graph.add( v1 );
		graph.add( v2 );
		graph.add( v3 );
		graph.add( v4 );
		graph.add( v5 );
		graph.add( v6 );

		graph.addEdge( v1, v6 );
		graph.addEdge( v2, v1 );
		graph.addEdge( v2, v3 );
		graph.addEdge( v2, v4 );
		graph.addEdge( v3, v4 );
		graph.addEdge( v3, v5 );
		graph.addEdge( v5, v4 );
		graph.addEdge( v5, v6 );

		// Nun koennen wir mit dem Graphen arbeiten...
		System.out.println(graph);
		System.out.println("Transitiver Abschluss:");
		WarshallRoy.transClosure(graph);
		System.out.println(graph);
	}

	public static void main(String[] args) throws Exception {
		@SuppressWarnings("unused")
		Aufgabe2 test = new Aufgabe2();
	}
}
