
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import huffman.Huffman;

/**
 * GUI-Klasse: KodierungGUI</br>
 * Aufgabe: Kodieren und Dekodieren eines Textes von der Konsole 
 *          mit Huffman-Algorithmus
 */
public class KodierungGUI
{
	public static void main(String args[])
	throws IOException
	{
		String eingabe;

		BufferedReader din = new BufferedReader(
				new InputStreamReader(System.in));
		System.out.print("Bitte eine Zeichenkette eingeben: ");
		eingabe = din.readLine();

		Huffman huffman = new Huffman(eingabe);
		huffman.countCharacters();
		huffman.printFrequencies();
		huffman.generateEncodingTree();
		huffman.printEncodingTree();
		huffman.generateCodeTable(); //  EncodingTree muss vorher generiert worden sein
		String encoded = huffman.encodeText();
		System.out.println("Encoded text: " + encoded);
		System.out.println("Decoded text: " + huffman.decodeText(encoded));
	}
}
