package huffman;
/**
 * Klasse zur Ausgabe eines Binaerbaums auf der Konsole
 * 
 * @author Ralf Vandenhouten
 */
public class TreeView
{
	//Attribut
	private Node root;

	//Konstruktor
	public TreeView(Node aTree)
	{
		this.root = aTree;
	}

	//Ausgabe
	public void printTree()
	{
		printSubTree(root, 0);
	}

	//rekursive Ausgabe der Zeichen-Schluessel
	public void printSubTree(Node subTree, int indentDepth)
	{
		String Zeichen;

		if(subTree != null)
		{
			//rekursiver Aufruf
			printSubTree(subTree.getNodeRight(), indentDepth+2);
			Zeichen = "" + subTree.getKey();
			for (int i=0; i<indentDepth; i++)
				System.out.print(" ");
			System.out.println(Zeichen);
			//rekursiver Aufruf
			printSubTree(subTree.getNodeLeft(), indentDepth+2);
		}
	}
}
