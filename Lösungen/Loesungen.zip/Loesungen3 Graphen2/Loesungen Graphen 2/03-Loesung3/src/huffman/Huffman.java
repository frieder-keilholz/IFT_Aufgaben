package huffman;
import java.util.*;

/**
 * Huffman-Coding mit Binaerbaeumen
 * TH Wildau
 * @author Ralf Vandenhouten
 */
public class Huffman {

    private String text;
    private Vector<Map.Entry<Character,Integer>> charFrequencies = null;
    private Node huffmanTree = null;
    private Hashtable<Character,String> codeTable = null;
    private Hashtable<String,Character> decodeTable = null;

    /**
     * Constructor for the Huffman class
     *
     * @param   text    String that is to be encoded.
     */
    public Huffman(String text) {
        this.text = text;
    }

    /**
     * Counts the frequencies of all characters in the current text.
     */
    public void countCharacters() {
        HashMap<Character,Integer> charCountMap = new HashMap<Character,Integer>();

        for (int i=0; i<text.length(); i++)
        {
            Character ch = text.charAt(i);
            int count = 1;
            if ( charCountMap.containsKey(ch) )
                count = ((Integer)charCountMap.get(ch)).intValue() + 1;
            charCountMap.put( ch, count);
        }
        this.charFrequencies = new Vector<Map.Entry<Character,Integer>>(charCountMap.entrySet());
        // Sortieren der Zeichen nach ihren Haeufigkeiten
        Collections.sort(charFrequencies,
            new Comparator<Map.Entry<Character,Integer>>() {
                public int compare( Map.Entry<Character,Integer> obj1, Map.Entry<Character,Integer> obj2 ) {
                    int i1 = obj1.getValue();
                    int i2 = obj2.getValue();

                    if( i1 < i2 )
                        return -1;
                    else if( i1 > i2 )
                        return 1;
                    else
                        return 0;
                }

                public boolean equals( Object obj ) {
                    return obj.equals( this );
                }
            });
    }

    /**
     * Generates the binary Huffman encoding tree from the Vector
     * <code>charFrequencies</code> that contains the frequencies of the
     * occuring characters in the text.
     */
    public void generateEncodingTree() {
        Node links, rechts, wurzel=null;
        // Dieser Vector speichert alle Teilbaeume, aus denen der Huffman-Baum
        // konstruiert wird
        Vector<Node> nodeVector = new Vector<Node>();

        // Initialisieren der Teilbaumliste (bereits sortiert!) mit den Einzelzeichen
        for (int i=0; i<charFrequencies.size(); i++)
            nodeVector.add(new Node(charFrequencies.get(i), null, null));

        // Zusammensetzen der Teilbaeume entsprechend ihrer Haeufigkeiten
        while (nodeVector.size() > 0) {
            links = (Node)nodeVector.remove(0);
            if (nodeVector.size()>0)
                rechts = (Node)nodeVector.remove(0);
            else {
                wurzel = links;
                break;
            }
            CharMapEntry newEntry = new CharMapEntry('*');
            // Haeufigkeit des neuen Baums ist die Summe der Haeufigkeiten der
            // beiden Teilbaeume
            int wurzelWert =
                links.getKey().getValue() + rechts.getKey().getValue();
            newEntry.setValue(wurzelWert);
            wurzel = new Node(newEntry, links, rechts);
            // Neuen Baum wieder in die Liste der Teilbaeume einfuegen, so dass
            // die Sortierung erhalten bleibt. Das Suchen der richtigen Position
            // erfolgt mit binaerer Suche.
            int lower = 0, upper = nodeVector.size()-1;
            while ( upper > lower ) {
                int middle = (upper+lower)/2;
                Integer wert = nodeVector.elementAt(middle).getKey().getValue();
                if ( wert.intValue() < wurzelWert )
                    lower = middle + 1;
                else
                    upper = middle;
            }
            if (nodeVector.size()>0) {
                Integer wert = (Integer)((Node)nodeVector.elementAt(lower))
                                          .getKey().getValue();
                if (wert.intValue() < wurzelWert)
                    lower++;
            }
            nodeVector.insertElementAt(wurzel, lower);
        }
        huffmanTree = wurzel;
    }

    /**
     * Generates the Huffman code table for all occuring characters by
     * using the Huffman tree.
     */
    public void generateCodeTable() {
        codeTable = new Hashtable<Character,String>();
        decodeTable = new Hashtable<String,Character>();
        huffmanCode(huffmanTree, "");
        System.out.println("Code table:\n" + codeTable);
    }

    /**
     * Recursive procedure for generating the Huffman code.
     * The Huffman codes are stored in <code>codeTable</code> and
     * <code>decodeTable</code>.
     *
     * @param node The root node of the character encoding tree.
     * @param code The (prefix) string used for the code of this tree.
     */
    public void huffmanCode(Node node, String code) {
        Node links = node.getNodeLeft();
        Node rechts = node.getNodeRight();
        // Nur Blaetter werden in Code-Tabelle eingetragen
        if (links == null && rechts == null) { // Blatt
            codeTable.put(node.getKey().getKey(), code); // Einfuegen  von Buchstabe und  Binaercode in codeTable
            decodeTable.put(code, node.getKey().getKey()); // Umgekehrtes Einfügen für Dekodierung (decodeTable)
            return;
        } else { // innerer Knoten
        	// Rekursiver Aufruf fuer den linken Teilbaum
        	if (links != null)
        		huffmanCode(links, code+"0");
        	// Rekursiver Aufruf fuer den rechten Teilbaum
        	if (rechts != null)
        		huffmanCode(rechts, code+"1");
        }
    }

    /**
     * Performs the encoding of the text based on the <code>codeTable</code>.
     * @return The encoded text.
     */
    public String encodeText(String text) {
        String result = "";

        for (int i=0; i<text.length(); i++)
            result += codeTable.get( text.charAt(i) );

        return result;
    }

    public String encodeText() {
        return encodeText(this.text);
    }

    /**
     * Performs the decoding of the text based on the <code>codeTable</code>.
     * @return The decoded text.
     */
    public String decodeText(String text) {
        String code = "";
        String result = "";

        for (int i=0; i<text.length(); i++) {
            code += text.charAt(i);
            if (decodeTable.containsKey(code)) {
                result += decodeTable.get(code);
                code = "";
            }
        }
        return result;
    }

    /**
     * Prints the frequencies of all characters as computed by countCharacters()
     * @see #countCharacters
     */
    public void printFrequencies() {
    	for ( Map.Entry<Character,Integer> mapEntry : charFrequencies ) {
            System.out.println((Character)mapEntry.getKey() + " " +
                               (Integer)mapEntry.getValue());
        }
    }

    /**
     * Prints the Huffman tree. generateEncodingTree() must be called first.
     */
    public void printEncodingTree() {
        TreeView ba = new TreeView(huffmanTree);
        System.out.println("Huffman tree:");
        ba.printTree();
    }

    /**
     * Inner class for representation of the char-frequency mapping entries.
     */
    class CharMapEntry implements Map.Entry<Character,Integer> {
        Character key;
        Integer value;
        public CharMapEntry(Character key) {
            this.key = key;
        }
        public boolean equals(Object o) {
            return false;
        }
        public Character getKey() {
            return this.key;
        }
        public Integer getValue() {
            return this.value;
        }
        public int hashCode() {
            return key.hashCode()+value.hashCode();
        }
        public Integer setValue(Integer value) {
            this.value = value;
            return this.value;
        }
        public String toString() {
            return key.toString()+"="+value.toString();
        }
    }
}

