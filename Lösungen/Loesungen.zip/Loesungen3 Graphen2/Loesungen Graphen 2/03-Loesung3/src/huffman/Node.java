package huffman;
import java.util.*;

/**
 * Binaerknotenklasse
 * 
 * @author Ralf Vandenhouten
 */
public class Node
{
	//Attribute
	private Map.Entry<Character,Integer> key; //allgemein: Object Daten mit Speicherung des Schluessels
	private Node subTreeLeft;
	private Node subTreeRight;

	//Konstruktor
	public Node(Map.Entry<Character,Integer> key, Node subTreeLeft, Node subTreeRight)
	{
		this.key = key;
		this.subTreeLeft = subTreeLeft;
		this.subTreeRight = subTreeRight;
	}

	//Standardoperationen
	public Map.Entry<Character,Integer> getKey() { return key; }
	public Node getNodeLeft() { return subTreeLeft; }
	public Node getNodeRight() { return subTreeRight; }

	public void setKey(Map.Entry<Character,Integer> key) {this.key = key; }
	public void setSubTreeLeft(Node subTreeLeft) {this.subTreeLeft = subTreeLeft; }
	public void setSubTreeRight(Node subTreeLeft) {this.subTreeLeft = subTreeLeft; }
}
