public class BonusVacationVisitor implements Visitor
{
    int total_days;

    public BonusVacationVisitor()
    {
        total_days = 0;
    }

    public int getTotalDays()
    {
        return total_days;
    }

    public void visit(Boss boss)
    {
        // Einfaches Aufaddieren der VacationDays fuer die Bosse.
        total_days += boss.getVacDays();
        // Zusätzlich werden die Bonustage, die nur die Bosse besitzen, dazu addiert.
        total_days += boss.getBonusDays();
    }                             
    // Einfaches Aufaddieren der VacationDays fuer die Employees.
    public void visit(Employee emp)
    {
        total_days += emp.getVacDays();
    }
}
