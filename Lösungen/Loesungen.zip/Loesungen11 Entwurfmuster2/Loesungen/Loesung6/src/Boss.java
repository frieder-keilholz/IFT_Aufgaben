public class Boss extends Employee
{
   private int bonusDays;

   public Boss(String name, float salary, int vacdays, int sickdays)
   {
      super(name, salary, vacdays, sickdays);
   }
   public void setBonusDays(int bonus)
   {
      bonusDays = bonus;
   }
   public int getBonusDays()
   {
      return bonusDays;
   }   
   // Achtung: Diese Methode sieht zwar identisch aus wie in der Oberklasse,
   // ist sie aber nicht: Hier ist "this" vom Typ Boss, in der Oberklasse vom
   // Typ Employee. Der Visitor behandelt diese Objekte unterschiedlich.
   public void accept(Visitor v)
   {
      v.visit(this);
   }
}
