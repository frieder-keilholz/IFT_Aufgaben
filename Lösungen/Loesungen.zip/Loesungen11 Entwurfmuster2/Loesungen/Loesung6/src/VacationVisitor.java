public class VacationVisitor implements Visitor
{
    protected int total_days;
    public VacationVisitor()
    {
        total_days = 0;
    }

    public void visit(Employee emp) {
        // Einfaches Aufaddieren der VacationDays fuer die Employees.
        total_days += emp.getVacDays();
    }

    public void visit(Boss boss)
    {
        // Aufruf der visit-Methode fuer Employees, da hier keine Bonustage berechnet werden sollen.
        visit((Employee)boss);
    }

    public int getTotalDays()
    {
        return total_days;
    }
}
