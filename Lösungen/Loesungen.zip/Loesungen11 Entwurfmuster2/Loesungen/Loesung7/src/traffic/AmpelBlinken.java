/********************************************************************
 * $Id$
 *
 * (c) Copyright Ralf Vandenhouten
 * All rights reserved
 ********************************************************************/
package traffic;
 

/**
 * Zustandsklasse fuer blinkende Ampel
 * @author Ralf Vandenhouten
 */
public class AmpelBlinken extends AmpelZustand {
    private static AmpelBlinken instance;

    private AmpelBlinken() {
    }

    public static AmpelBlinken getInstance() {
        if (instance==null)
            instance = new AmpelBlinken();
        return instance;
    }

    @Override
    public AmpelZustand next() {
        return this;
    }
}
