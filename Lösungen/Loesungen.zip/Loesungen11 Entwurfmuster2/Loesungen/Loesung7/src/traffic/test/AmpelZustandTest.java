/********************************************************************
 * $Id$
 *
 * (c) Copyright Ralf Vandenhouten
 * All rights reserved
 ********************************************************************/
package traffic.test;

import org.junit.Before;
import org.junit.Test;
import traffic.*;

import static org.junit.Assert.*;
 

/**
 * Test fuer die Ampellogik nach dem Zustandsmuster
 * @author Ralf Vandenhouten
 */
public class AmpelZustandTest {
    
    private AmpelZustand state;

    /**
     * Vor jedem Testmethodenaufruf wird die Methode aufgerufen, die mit @Before markiert ist.
     * Damit hat jeder Test die gleichen Ausgangsbedingungen.
     *
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        state = AmpelBlinken.getInstance();
    }

    /**
     * Test method for {@link traffic.AmpelZustand#on()}.
     */
    @Test
    public final void testOn() {
        state = state.on();
        // erwartetes Ergebnis
        assertSame(AmpelRot.getInstance(), state);
    }

    /**
     * Test method for {@link traffic.AmpelZustand#blink()}.
     */
    @Test
    public final void testBlink() {
        state = state.blink();
        assertSame(AmpelBlinken.getInstance(), state);
    }

    /**
     * Test method for {@link traffic.AmpelZustand#next()}.
     */
    @Test
    public final void testNext() {

        testOn();
        state = state.next();
        assertSame(AmpelRotGelb.getInstance(), state);
        state = state.next();
        assertSame(AmpelGruen.getInstance(), state);
        state = state.next();
        assertSame(AmpelGelb.getInstance(), state);
        state = state.next();
        assertSame(AmpelRot.getInstance(), state);
    }
}
