/********************************************************************
 * $Id$
 *
 * (c) Copyright Ralf Vandenhouten
 * All rights reserved
 ********************************************************************/
package traffic;
 

/**
 * Zustandsklasse fuer gruene Ampel
 * @author Ralf Vandenhouten
 */
public class AmpelGruen extends AmpelZustand {
    private static AmpelGruen instance;

    private AmpelGruen() {
    }

    public static AmpelGruen getInstance() {
        if (instance==null)
            instance = new AmpelGruen();
        return instance;
    }

    @Override
    public AmpelZustand next() {
        return AmpelGelb.getInstance();
    }
}
