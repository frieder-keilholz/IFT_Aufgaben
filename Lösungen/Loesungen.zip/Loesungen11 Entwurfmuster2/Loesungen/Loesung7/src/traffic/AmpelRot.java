/********************************************************************
 * $Id$
 *
 * (c) Copyright Ralf Vandenhouten
 * All rights reserved
 ********************************************************************/
package traffic;
 

/**
 * Zustandsklasse fuer rote Ampel
 * @author Ralf Vandenhouten
 */
public class AmpelRot extends AmpelZustand {
    private static AmpelRot instance;

    private AmpelRot() {
    }

    public static AmpelRot getInstance() {
        if (instance==null)
            instance = new AmpelRot();
        return instance;
    }

    @Override
    public AmpelZustand next() {
        return AmpelRotGelb.getInstance();
    }
}
