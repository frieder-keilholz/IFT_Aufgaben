/********************************************************************
 * $Id$
 *
 * (c) Copyright Ralf Vandenhouten
 * All rights reserved
 ********************************************************************/
package traffic;
 

/**
 * Zustandsklasse fuer gelbe Ampel
 * @author Ralf Vandenhouten
 */
public class AmpelGelb extends AmpelZustand {
    private static AmpelGelb instance;

    private AmpelGelb() {
    }

    public static AmpelGelb getInstance() {
        if (instance==null)
            instance = new AmpelGelb();
        return instance;
    }

    @Override
    public AmpelZustand next() {
        return AmpelRot.getInstance();
    }
}
