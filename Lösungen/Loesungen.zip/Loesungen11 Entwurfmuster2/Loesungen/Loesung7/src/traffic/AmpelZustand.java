/********************************************************************
 * $Id$
 *
 * (c) Copyright Ralf Vandenhouten
 * All rights reserved
 ********************************************************************/
package traffic;
 

/**
 * Abstrakte Zustandsklasse fuer den Zustand einer Ampel
 * nach dem Zustandsmuster der Gang of Four
 * @author Ralf Vandenhouten
 */
public abstract class AmpelZustand {
    
    protected AmpelZustand() {
    }

    public AmpelZustand on() {
        return AmpelRot.getInstance();
    }
    
    public AmpelZustand blink() {
        return AmpelBlinken.getInstance();
    }
    
    public abstract AmpelZustand next();
}
