/********************************************************************
 * $Id$
 *
 * (c) Copyright Ralf Vandenhouten
 * All rights reserved
 ********************************************************************/
package traffic;
 

/**
 * Zustandsklasse fuer rot-gelbe Ampel
 * @author Ralf Vandenhouten
 */
public class AmpelRotGelb extends AmpelZustand {
    private static AmpelRotGelb instance;

    private AmpelRotGelb() {
    }

    public static AmpelRotGelb getInstance() {
        if (instance==null)
            instance = new AmpelRotGelb();
        return instance;
    }

    @Override
    public AmpelZustand next() {
        return AmpelGruen.getInstance();
    }
}
