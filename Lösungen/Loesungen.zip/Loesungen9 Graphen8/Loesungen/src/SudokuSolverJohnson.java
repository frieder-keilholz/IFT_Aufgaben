import graph.GraphImpl;
import graph.Vertex;
import graph.algorithm.JohnsonColoring;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

/**
 * Sudoku solver based on Johnson coloring
 * 
 * @author Ralf Vandenhouten
 */
public class SudokuSolverJohnson extends JohnsonColoring {
	
	private static final long serialVersionUID = 1L;

	/**
	 * The board of the Sudoku
	 */
	protected PointWithNumber[][] board;
	
	/**
	 * Number of predefined fields
	 */
	protected int numPredefined;
	
	/**
	 * Constructor that reads the Sudoku problem from a text file. Each line must contain exactly
	 * 9 digits between 0 and 9, where 0 denotes an empty field and the numbers 1-9 denote predefined
	 * fields of the Sudoku board.
	 * @param filename - the name of the file to be loaded
	 * @throws Exception 
	 */
	public SudokuSolverJohnson(String filename) throws Exception {
		super(new GraphImpl(false));
		board = new PointWithNumber[9][9];
		
		// Read Sudoku problem from the text file
		BufferedReader in = new BufferedReader(new InputStreamReader(
				new FileInputStream(filename)));
		for (int i=0; i<9; i++) {
			String line = in.readLine();
			for (int j=0; j<9; j++) {
				int number = Integer.parseInt(line.substring(j, j+1));
				board[i][j] = new PointWithNumber(i, j, number);
			}
		}
		in.close();
		
		// Create vertices for the predefined fields
		for (int i=0; i<9; i++) {
			for (int j=0; j<9; j++) {
				if (board[i][j].value != 0) {
					Vertex v = new Vertex(board[i][j]); 
					graph.add(v);
					colorMap.put(v, board[i][j].value);
					numPredefined++;
				}
			}
		}
		
		// Create vertices for the empty fields
		for (int i=0; i<9; i++) {
			for (int j=0; j<9; j++) {
				if (board[i][j].value == 0) 
					graph.add(new Vertex(board[i][j]));
			}
		}
		
		// Create the edges
		List<Vertex> vertices = graph.getVertices();
		for (int i=0; i<vertices.size(); i++) {
			Vertex v1 = vertices.get(i);
			PointWithNumber p1 = (PointWithNumber)v1.getObject();
			for (int j=0; j<vertices.size(); j++) {
				if (j==i) continue;
				Vertex v2 = vertices.get(j);
				PointWithNumber p2 = (PointWithNumber)v2.getObject();
				// Check conflict conditions
				if (p1.x==p2.x || p1.y==p2.y 
						|| ((p1.x/3==p2.x/3) && (p1.y/3==p2.y/3)))
					graph.addEdge(v1, v2);
			}
		}
	}
	
	/**
	 * This method solves the Sudoku game by Johnson coloring the corresponding conflict graph
	 * @throws Exception if unsolvable
	 */
	public void solve() throws Exception {
		Map<Vertex, Integer> colorMap = coloring(9);
		for (Vertex v: graph.getVertices()) {
			((PointWithNumber)v.getObject()).value = colorMap.get(v);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer out = new StringBuffer();
		for (int i=0; i<9; i++) {
			for (int j=0; j<9; j++) {
				out.append("" + board[i][j].value + " ");
			}
			out.append("\n");
		}
		return out.toString();
	}
	
	/**
	 * Helper class for handling the fields of the Sudoku board
	 */
	class PointWithNumber {
		public int x, y;
		public int value;
		
		public PointWithNumber(int x, int y, int value) {
			this.x = x;
			this.y = y;
			this.value = value;
		}
		
		public PointWithNumber(int x, int y) {
			this(x, y, 0);
		}
	}
}
