import graph.*;
import graph.algorithm.*;

public class Aufgabe2 {

	public Aufgabe2() throws Exception {
		WeightedGraph graph = new WeightedGraphImpl( false );
		final int N = 20;
		final int p = 7;
		int i, j;
		Vertex  v[] = new Vertex[N];
		double x[] = new double[N];
		double y[] = new double[N];

		for (i=0; i<N; i++) {
			// Die Kunden sind die Ecken
			v[i] = new Vertex( ""+(i+1) );
			// Wir definieren zu jeder Ecke einen Punkt (x,y) in der Ebene, ...
			x[i] = Math.cos(2*Math.PI*p*i/N);
			y[i] = Math.sin(2*Math.PI*p*i/N);
			graph.add( v[i] );
		}
		// ... denn damit ergibt sich die Bewertung einer Kante gemaess
		// Aufgabenstellung als der Abstand der zugehoerigen Punkte in der Ebene.
		// Damit ist auch bewiesen, dass die Dreiecksungleichung Dij + Djk >= Dik
		// fuer beliebige Kanten des Graphen erfuellt wird.
		for (i=0; i<N; i++)
			for (j=i+1; j<N; j++)
				graph.addEdge( v[i], v[j],
						Math.sqrt( (x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]) ));

		System.out.println("\n*************** Aufgabe 2 *****************");
		System.out.println("Graph:\n" + graph);
		TravelingSalesman tsp = new TravelingSalesman( graph );
		// Da die Dreiecksungleichung vom Graphen erfuellt wird, kann der
		// approximative Algorithmus aus der Vorlesung verwendet werden.
		System.out.println("Traveling salesman path (approximation): " +
				tsp.travelingSalesmanPathApproximation() );
		System.out.println("Weglaenge = " + tsp.getPathLength() + " km");
		/* Vorsicht: Je nach Groesse von N terminiert das Back-Tracking nicht
         * in einer ueberschaubaren Zeit! */
		System.out.println("Optimum traveling salesman path: " +
				tsp.travelingSalesmanPathBackTrack() );
		System.out.println("Weglaenge = " + tsp.getPathLength() + " km");
		/**/
	}

	public static void main(String[] args) throws Exception {
		new Aufgabe2();
	}
}
