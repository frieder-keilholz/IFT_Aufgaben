/**
 * Program for solving Sudokus
 * 
 * @author Ralf Vandenhouten
 */
public class Sudoku {

	public static void main(String[] args) throws Exception {
//		SudokuSolverJohnson sudoku = new SudokuSolverJohnson("Sudoku1.txt");
		SudokuSolverSorted sudoku = new SudokuSolverSorted("Sudoku1.txt");
		long t1 = System.currentTimeMillis();
		sudoku.solve();
		long t2 = System.currentTimeMillis();
		System.out.println(sudoku);
		System.out.println("Solved in " + (t2-t1) + "ms.");
	}
}
