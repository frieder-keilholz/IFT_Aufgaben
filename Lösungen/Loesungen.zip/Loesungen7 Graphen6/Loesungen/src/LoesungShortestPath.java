public class LoesungShortestPath {

	public static void main(String[] args) throws Exception {
		System.out.println("******************** Loesungen **********************");
		new Aufgabe1();
		new Aufgabe2();
		new Aufgabe3();
	}
}
