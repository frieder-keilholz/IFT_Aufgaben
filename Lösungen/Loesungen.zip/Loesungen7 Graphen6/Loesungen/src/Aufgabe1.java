import util.*;
import graph.*;
import graph.algorithm.*;

public class Aufgabe1 {

	public Aufgabe1() throws Exception {
		WeightedGraph graph = new WeightedGraphImpl( false ); // ungerichtet
		Vertex  v[] = new Vertex[6];
		int i, index=-1;

		double min = Double.POSITIVE_INFINITY;
		WeightedGraph shortestPathTree;

		for (i=0; i<6; i++) {
			v[i] = new Vertex( ""+(i+1) );
			graph.add( v[i] );
		}

		graph.addEdge( v[0], v[1], 100 );
		graph.addEdge( v[1], v[2], 150 );
		graph.addEdge( v[1], v[3], 200 );
		graph.addEdge( v[1], v[4], 40 );
		graph.addEdge( v[2], v[3], 30 );
		graph.addEdge( v[2], v[5], 70 );
		graph.addEdge( v[4], v[5], 120 );

		System.out.println("********** Aufgabe 1 ****************");
		System.out.println("Graph:\n" + graph);

		// Verwende Dijkstra-Algorithmus zur Bestimmung der kuerzesten-Wege-Baeume
		ShortestPathAlgorithm spa =
			new ShortestPathAlgorithmDijkstra( graph, new HeapNodeComparator(-1) );
		// Berechne fuer alle Knoten den kuerzesten-Wege-Baum...
		for ( i=0; i<6; i++ ) {
			//shortestPathTree = spa.shortestPath( v[i] );
			spa.shortestPath( v[i] );
			// ... und bestimme darin die groesste Distanz zu einem anderen Knoten
			double maxDistance = spa.getLongestDistance( v[i] );
			// Die minimale Maximaldistanz wird festgehalten
			if ( maxDistance < min ) {
				min = maxDistance;
				index = i;
			}
		}
		shortestPathTree = spa.shortestPath( v[index] );
		System.out.println("Optimaler Serverknoten: " + v[index]);
		System.out.println("Shortest Path Tree:\n" + shortestPathTree);
		System.out.println("Weiteste Entfernung: " + spa.getLongestDistance(v[index]));
	}

	public static void main(String[] args) throws Exception {
		new Aufgabe1();
	}
}
