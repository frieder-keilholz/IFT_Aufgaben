import util.*;
import graph.*;
import graph.algorithm.*;

public class Aufgabe2 {

  public Aufgabe2() throws Exception {
    WeightedGraph graph = new WeightedGraphImpl( false ); // ungerichtet
    Vertex  v[] = new Vertex[9];
    WeightedGraph shortestPathTree;
    int i;

    for (i=0; i<9; i++) {
        v[i] = new Vertex( ""+(i+1) );
        graph.add( v[i] );
    }

    // 1. Problem: Algorithmus arbeitet mit Addition der Kantenbewertung, hier ist aber die
    // Multiplikation der Kantenbewertungen zur Berechnung der Wahrscheinlichkeit nötig.
    //
    // Lösung:
    // Es gilt log(x) + log(y) = log(xy)
    //
    // 2. Problem: Algorithmus sucht Weg mit minimalen Kosten, hier ist jedoch maximale Wahrscheinlichkeit gesucht.
    // Lösung:
    // Da ausserdem pW (Uebertagungswahrscheinlichkeit für den Weg W)
    // genau dann maximal wird, wenn -log(pW) minimal wird, hat man einen optimalen Weg
    // genau dann gefunden, wenn man einen kuerzesten Weg in dem mit den -log(p)
    // kantenbewerteten Graphen gefunden hat.
    // (-log(x)) + (-log(y)) = -log(xy)
    // Daraus folgt die Zulaessigkeit der Transformation p -> -log(p).


    graph.addEdge( v[0], v[7], -Math.log(0.9) );
    graph.addEdge( v[1], v[2], -Math.log(0.6) );
    graph.addEdge( v[1], v[7], -Math.log(0.9) );
    graph.addEdge( v[2], v[3], -Math.log(0.9) );
    graph.addEdge( v[2], v[8], -Math.log(0.9) );
    graph.addEdge( v[3], v[4], -Math.log(0.8) );
    graph.addEdge( v[3], v[5], -Math.log(0.9) );
    graph.addEdge( v[3], v[6], -Math.log(0.7) );
    graph.addEdge( v[3], v[8], -Math.log(0.6) );
    graph.addEdge( v[4], v[5], -Math.log(0.8) );
    graph.addEdge( v[6], v[7], -Math.log(0.8) );
    graph.addEdge( v[6], v[8], -Math.log(0.6) );
    graph.addEdge( v[7], v[8], -Math.log(0.7) );

    System.out.println("********** Aufgabe 2 ****************");
    System.out.println("Graph:\n" + graph);

    ShortestPathAlgorithm spa =
        new ShortestPathAlgorithmDijkstra( graph, new HeapNodeComparator(-1) );
    shortestPathTree = spa.shortestPath( v[0] );
    System.out.println("Shortest Path Tree:\n" + shortestPathTree);
    System.out.println("Weg von 1 nach 5: " + spa.getShortestPath(v[0],v[4]));
    // Um die Uebertragungswahrscheinlichkeit anzugeben, muss mit der Umkehrfunktion
    // exp(-distance) wieder zuruecktransformiert werden!
    System.out.println("Uebertragungswahrscheinlichkeit auf diesem Weg: " +
                       Math.exp( - spa.getDistance( v[0], v[4] ) ));
  }
  public static void main(String[] args) throws Exception {
    new Aufgabe2();
  }
}
