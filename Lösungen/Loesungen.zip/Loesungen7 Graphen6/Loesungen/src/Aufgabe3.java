import util.*;
import graph.*;
import graph.algorithm.*;

public class Aufgabe3 {

	public Aufgabe3() throws Exception {
		WeightedGraph graph = new WeightedGraphImpl( true ); // gerichtet
		Vertex  v1, v2, v3, v4, v5, v6, v7;

		v1 = new Vertex( "1" );
		v2 = new Vertex( "2" );
		v3 = new Vertex( "3" );
		v4 = new Vertex( "4" );
		v5 = new Vertex( "5" );
		v6 = new Vertex( "6" );
		v7 = new Vertex( "7" );

		graph.add( v1 );
		graph.add( v2 );
		graph.add( v3 );
		graph.add( v4 );
		graph.add( v5 );
		graph.add( v6 );
		graph.add( v7 );

		graph.addEdge( v1, v2, 5 );
		graph.addEdge( v1, v5, 3 );
		graph.addEdge( v2, v1, 3 );
		graph.addEdge( v2, v3, 3 );
		graph.addEdge( v2, v5, 5 );
		graph.addEdge( v3, v2, 3 );
		graph.addEdge( v3, v4, 3 );
		graph.addEdge( v4, v3, 3 );
		graph.addEdge( v4, v6, 2 );
		graph.addEdge( v4, v7, 2 );
		graph.addEdge( v5, v1, 3 );
		graph.addEdge( v5, v2, 3 );
		graph.addEdge( v5, v6, 1 );
		graph.addEdge( v6, v4, 4 );
		graph.addEdge( v6, v5, 2 );
		graph.addEdge( v6, v7, 2 );
		graph.addEdge( v7, v4, 2 );
		graph.addEdge( v7, v6, 4 );

		System.out.println("********** Aufgabe 3 ****************");
		System.out.println("Graph:\n" + graph);

		ShortestPathAlgorithm spa =
			new ShortestPathAlgorithmDijkstra( graph, new HeapNodeComparator(-1) );
		WeightedGraph shortestPathTree = spa.shortestPath( v2 );
		System.out.println("Shortest Path Tree fuer Knoten 2:\n" + shortestPathTree);
		System.out.println("Routing-Tabelle fuer Knoten 2: " + spa.getRoutingTable(v2));
	}

	public static void main(String[] args) throws Exception {
		new Aufgabe3();
	}
}
