// adapter interface for adapting a JList
// object to the AWT List operations
public interface IAwtList
{
	public void add(String s);
	public void remove(String s);
	public String[] getSelectedItems();
}

