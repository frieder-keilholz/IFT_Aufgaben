import java.util.List;
import java.util.Vector;

import javax.swing.AbstractListModel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * This is a simple object adapter class to
 * convert AWT List methods to Swing methods
 */
public class JAwtList extends JScrollPane
implements ListSelectionListener, IAwtList
{
	private static final long serialVersionUID = 1L;
	private JList<String> listWindow;
	private JListData listContents;
	//-----------------------------------------
	public JAwtList(int rows)
	{
		listContents = new JListData();
		listWindow = new JList<String>(listContents);
		listWindow.setPrototypeCellValue("Abcdefg Hijklmnop");
		getViewport().add(listWindow);

	}
	//-----------------------------------------
	public void add(String s)
	{
		listContents.addElement(s);
	}
	//-----------------------------------------
	public void remove(String s)
	{
		listContents.removeElement(s);
	}
	//-----------------------------------------
	public String[] getSelectedItems()
	{
		List<String> list = listWindow.getSelectedValuesList();
		String[] s = new String[list.size()];
		for (int i =0; i<list.size(); i++) 
			s[i] = list.get(i);
		return s;
	}
	//-----------------------------------------
	public void valueChanged(ListSelectionEvent e)
	{
	}
}
//  Modell fuer die Swing-Liste
//  =========================================
class JListData extends AbstractListModel<String>
{
	private static final long serialVersionUID = 1L;

	private Vector<String> data;
	//-----------------------------------------
	public JListData()
	{
		data = new Vector<String>();
	}
	//-----------------------------------------
	public int getSize()
	{
		return data.size();
	}
	//-----------------------------------------
	public String getElementAt(int index)
	{
		return data.elementAt(index);
	}
	//-----------------------------------------
	public void addElement(String s)
	{
		data.addElement(s);
		fireIntervalAdded(this, data.size()-1, data.size());
	}
	//-----------------------------------------
	public void removeElement(String s)
	{
		data.removeElement(s);
		fireIntervalRemoved(this, 0, data.size());
	}
}

