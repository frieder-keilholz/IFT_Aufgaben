import java.util.Vector;

public interface ILister {

    ProductList makeList(Vector<String> v);

    ProductTable makeTable(Vector<String> v);

}
