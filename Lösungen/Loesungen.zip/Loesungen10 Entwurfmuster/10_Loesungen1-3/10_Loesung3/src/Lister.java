import java.util.Collections;
import java.util.Vector;

import javax.swing.JScrollPane;

/**
 *  Klasse Lister
 *  Entwurfsmuster: Bruecke
 *  Abstrahiert die beiden Listen-Implementierungen
 *  ProductList und ProductTable
 *  und initialisiert sie mit sortierten Vektoren
 */
public class Lister extends JScrollPane implements ILister{
	public static final int TABLE=1;
	public static final int LIST=2;

	public Lister(Vector<String> v, int tableType) {
		Vector<String> sort = sortVector(v);

		if (tableType==TABLE)
			getViewport().add(makeTable(sort));
		if (tableType==LIST)

			getViewport().add(makeList(sort));
	}

	public ProductList makeList(Vector<String> v) {
		return new ProductList(v);
	}

	public ProductTable makeTable(Vector<String> v) {
		return new ProductTable(v);
	}

	// Gibt eine sortierte Kopie des Vektors v zurueck
	private Vector<String> sortVector(Vector<String> v) {
		Vector<String> nv = new Vector<>(v);
		Collections.sort(nv);
		return nv;
	}
}

