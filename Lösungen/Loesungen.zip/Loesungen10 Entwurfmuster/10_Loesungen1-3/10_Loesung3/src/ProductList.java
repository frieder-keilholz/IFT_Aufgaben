import java.util.Vector;

public class ProductList extends java.awt.List
{
	private static final long serialVersionUID = 1L;

	public ProductList(Vector<String> products)
	{
		super(products.size());    //for compatibility
		for (int i = 0; i < products.size(); i++)
		{
			//take each string apart and keep only
			//the product names, discarding the quantities
			String s = products.elementAt(i);
			int index = s.indexOf("--");  //separate qty from name
			if(index > 0)
				add(s.substring(0, index));
			else
				add(s);
		}
	}
}
