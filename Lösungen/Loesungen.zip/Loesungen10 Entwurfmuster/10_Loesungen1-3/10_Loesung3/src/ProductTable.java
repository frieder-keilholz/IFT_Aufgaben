
import java.util.Vector;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

public class ProductTable extends JScrollPane
{
	private static final long serialVersionUID = 1L;

	JTable table;
	public ProductTable(Vector<String> list)
	{
		table = new JTable(new prodModel(list));
		getViewport().add(table);
	}
}

class prodModel implements TableModel
{
	private int rows;
	private int columns;
	private Vector<String> prodNames;
	private Vector<String> quantities;

	public prodModel(Vector<String> products)
	{
		rows  = products.size();
		columns = 2;
		prodNames = new Vector<String>();
		quantities =  new Vector<String>();
		for(int i=0; i< products.size(); i++)
		{
			String s = (String)products.elementAt(i);
			int index = s.indexOf("--");  //separate qty from name
			if(index > 0)
			{
				prodNames.addElement(s.substring(0, index));
				quantities.addElement(s.substring(index+2).trim());
			}
			else
				prodNames.addElement(s);

		}
	}
	public int getColumnCount()
	{
		return columns;
	}
	public int getRowCount()
	{
		return rows;
	}
	public Object getValueAt(int r, int c)
	{
		switch (c)
		{
		case 0:
			return prodNames.elementAt(r);

		case 1:
			return quantities.elementAt(r);

		default:
			return prodNames.elementAt(r);

		}

	}
	public Class<?> getColumnClass(int c)
	{
		return String.class;
	}
	public boolean isCellEditable(int r, int c){return false;}
	public String getColumnName(int c){return "";}
	public void setValueAt(Object obj, int r, int c){}
	public void addTableModelListener(TableModelListener tbm){}
	public void removeTableModelListener(TableModelListener tbm){}
}
