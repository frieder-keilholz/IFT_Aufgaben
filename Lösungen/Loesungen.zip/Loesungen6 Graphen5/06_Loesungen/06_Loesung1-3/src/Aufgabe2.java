import graph.*;
import graph.algorithm.*;

public class Aufgabe2 {

	public Aufgabe2() throws Exception {
		Network net = new NetworkImpl();
		Vertex  q, R1, R2, R3, R4, R5, F1, F2, F3, F4, F5, s;

		// Netzwerk, das die Aufgabe repraesentiert
		q = new Vertex( "q" );
		R1 = new Vertex( "R1" );
		R2 = new Vertex( "R2" );
		R3 = new Vertex( "R3" );
		R4 = new Vertex( "R4" );
		R5 = new Vertex( "R5" );
		F1 = new Vertex( "F1" );
		F2 = new Vertex( "F2" );
		F3 = new Vertex( "F3" );
		F4 = new Vertex( "F4" );
		F5 = new Vertex( "F5" );
		s = new Vertex( "s" );

		net.add( q );
		net.add( R1 );
		net.add( R2 );
		net.add( R3 );
		net.add( R4 );
		net.add( R5 );
		net.add( F1 );
		net.add( F2 );
		net.add( F3 );
		net.add( F4 );
		net.add( F5 );
		net.add( s );
		net.setSource( q );
		net.setSink( s );

		// Erstellung der Kanten ohne Kapazitaeten, da 0-1 Netzwerk.
		// Wenn Kapazitaet = 0 --> keine Kante, wenn Kapazitaet = 1 --> Kante hinzufuegen
		net.addEdge( q, R1 );
		net.addEdge( q, R2 );
		net.addEdge( q, R3 );
		net.addEdge( q, R4 );
		net.addEdge( q, R5 );
		net.addEdge( R1, F2 );
		net.addEdge( R1, F5 );
		net.addEdge( R2, F1 );
		net.addEdge( R2, F4 );
		net.addEdge( R3, F2 );
		net.addEdge( R3, F3 );
		net.addEdge( R4, F3 );
		net.addEdge( R4, F5 );
		net.addEdge( R5, F3 );
		net.addEdge( R5, F2 );
		net.addEdge( F1, s );
		net.addEdge( F2, s );
		net.addEdge( F3, s );
		net.addEdge( F4, s );
		net.addEdge( F5, s );

		// Berechne maximalen binaeren Fluss
		System.out.println("Hilfsnetzwerk:\n" + net);
		UnitCapacityNetworkFlow ucflow = new UnitCapacityNetworkFlow( net );
		ucflow.maximizeFlow();
		System.out.println("Maxmimale Zahl der Reporter: " + ucflow.getTotalFlow());
		System.out.println("Optimale Zuordnung:\n" + ucflow.getFlowMap());  
	}

	public static void main(String[] args) throws Exception {
		System.out.println("******************** Aufgabe 2 **********************");
		new Aufgabe2();
	}
}
