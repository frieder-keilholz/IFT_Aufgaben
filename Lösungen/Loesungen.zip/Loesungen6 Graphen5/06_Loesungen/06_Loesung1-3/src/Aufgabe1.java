import graph.*;
import graph.algorithm.*;

public class Aufgabe1 {

	public Aufgabe1() throws Exception {
		NetworkImpl net = new NetworkImpl();
		Vertex  q, s, v1, v2, v3, v4, v5, v6;

		// Das Beispielnetzwerk aus der Vorlesung
		q = new Vertex( "q" );
		s = new Vertex( "s" );
		v1 = new Vertex( "1" );
		v2 = new Vertex( "2" );
		v3 = new Vertex( "3" );
		v4 = new Vertex( "4" );
		v5 = new Vertex( "5" );
		v6 = new Vertex( "6" );

		net.add( q );
		net.add( v1 );
		net.add( v2 );
		net.add( v3 );
		net.add( v4 );
		net.add( v5 );
		net.add( v6 );
		net.add( s );
		net.setSource( q );
		net.setSink( s );

		// Einfuegen der Kanten inklusive der Kapazitaeten
		net.addEdge( q, v1, 40 );
		net.addEdge( q, v4, 20 );
		net.addEdge( v1, v2, 30 );
		net.addEdge( v2, v3, 10 );
		net.addEdge( v2, v6, 37 );
		net.addEdge( v3, s, 22 );
		net.addEdge( v4, v5, 54 );
		net.addEdge( v5, v3, 50 );
		net.addEdge( v6, v4, 17 );
		net.addEdge( v6, s, 32 );

		// Teste Flussberechnung
		System.out.println("Graph:\n" + net);
		AugmentNetworkFlow flow = new AugmentNetworkFlow( net );
		flow.maximizeFlow();

		System.out.println("Maximaler Fluss:\n" + flow.getFlowMap());
		System.out.println("Gesamtfluss: " + flow.getTotalFlow());
	}

	public static void main(String[] args) throws Exception {
		System.out.println("******************** Aufgabe 1 **********************");
		new Aufgabe1();
	}
}
