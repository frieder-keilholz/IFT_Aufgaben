package main;
import graph.*;

public class TestGraph {
    Vertex	v1, v2, v3, v4;
    Graph	graph;

    public TestGraph() throws Exception {

        graph = new GraphImpl(true); // true = gerichtet; false = ungerichtet

        // Zyklischer Graph mit 4 Ecken
        v1 = new Vertex( "1" );
        v2 = new Vertex( "2" );
        v3 = new Vertex( "3" );
        v4 = new Vertex( "4" );

        graph.add( v1 );
        graph.add( v2 );
        graph.add( v3 );
        graph.add( v4 );

        graph.addEdge( v1, v2 );
        graph.addEdge( v2, v3 );
        graph.addEdge( v3, v4 );
        graph.addEdge( v4, v1 );

        // Teste Basisoperationen des Graphen
        System.out.println(graph);
        System.out.println("Ist v3 Nachfolger von v1? " + graph.haveCommonEdge(v1, v3));
        System.out.println("Ist v4 Nachfolger von v1? " + graph.haveCommonEdge(v1, v4));
        System.out.println("Nachbarn von v1: " + graph.getAdjacentVertices(v1));
        System.out.println("Grad von v1: " + graph.getDegree(v1));
    }

    public static void main(String[] args) throws Exception {
        @SuppressWarnings("unused")
		TestGraph test = new TestGraph();
    }
}
