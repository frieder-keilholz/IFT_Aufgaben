/*
 * File State.java
 * $Id$
 *
 * (c) Copyright 2008 Ralf Vandenhouten
 * All rights reserved
 */
package pushpuzzle;

import java.util.Iterator;
 

/**
 * State speichert einen Momentanzustand (Snapshot) des Spielbrettes (max. 4x4)
 * @author Ralf Vandenhouten
 * @version $Revision$
 */
public class State implements Iterable<State> {
    /**
     * Breite und Hoehe des Puzzles
     */
    private int width;
    private int height;
    private int size;
    /**
     * Die max. 16 Zahlen von 0 bis 15 werden jeweils mit 4 Bits dargestellt,
     * so dass sie komplett in einem long-Wert gespeichert werden koennen.
     */
    private long signature;
    /**
     * Gibt die Position (bei zeilenweiser Durchnummerierung) an, die momentan
     * das freie Feld enthaelt.
     */
    private int free;
    
    /**
     * Standard-Konstruktor
     * @param width - Breite des Puzzles
     * @param height - Hoehe des Puzzles
     */
    public State(int width, int height) {
        this.width = width;
        this.height = height;
        this.size = width*height;
        signature = 0;
        for (long i=0; i<size-1; i++)
            signature += (i+1) << (i*4);
        free = size-1;
    }
    
    /**
     * Konstruktor mit gegebener Spielstellung
     * @param width - Breite des Puzzles
     * @param height - Hoehe des Puzzles
     * @param signature - Signatur der aktuellen Stellung
     */
    public State(int width, int height, long signature) {
        this(width, height);
        this.signature = signature;
        long i;
        for (i=0; i<size; i++)
            if ((signature & (0xfl << i*4)) == 0)
                break;
        free = (int)i;
    }
    
    /**
     * Erzeugt einen Iterator ueber die moeglichen Nachbarstellungen
     */
    public Iterator<State> getNeighborStates() {
        return new StateIterator();
    }
    
    /*
     * (non-Javadoc)
     * @see java.lang.Iterable#iterator()
     */
    @Override
    public Iterator<State> iterator() {
        return getNeighborStates();
    }
    
    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object other) {
        return ((State)other).signature == signature;
    }
    
    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        // Gibt die 8 Hex-Ziffern rund um die Position 'free' als Hashcode zurueck
        int pos = free - 4;
        if (pos > size - 8)
            pos = size - 8;
        if (pos < 0)
            pos = 0;
        return (int)(signature >> (pos*4));
    }
    
    /**
     * @return the width
     */
    public int getWidth() {
        return width;
    }

    
    /**
     * @param width the width to set
     */
    public void setWidth(int width) {
        this.width = width;
    }

    
    /**
     * @return the height
     */
    public int getHeight() {
        return height;
    }

    
    /**
     * @param height the height to set
     */
    public void setHeight(int height) {
        this.height = height;
    }

    
    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    
    /**
     * @param size the size to set
     */
    public void setSize(int size) {
        this.size = size;
    }

    
    /**
     * @return the signature
     */
    public long getSignature() {
        return signature;
    }

    
    /**
     * @param signature the signature to set
     */
    public void setSignature(long signature) {
        this.signature = signature;
    }

    
    /**
     * @return the free position
     */
    public int getFree() {
        return free;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        long sig = signature;
        String result = "\n";
        for (int i=0; i<height; i++) {
            for (int j=0; j<width; j++) {
                long value = sig & 0xfl;
                sig >>= 4;
                if (value<10)
                    result += value;
                else
                    result += (char)('A'+(value-10));
            }
            result += '\n';
        }
        return result;
    }
    
    /**
     * StateIterator ist eine innere Klasse zum Iterieren der Nachbarzustaende
     */
    class StateIterator implements Iterator<State>
    {
        /**
         * Die Nachbarstellungen werden durch die relative Position des 
         * zu tauschenden Steins zum freien Feld definiert
         */
        private final long[] offsetX = {0, -1, 1, 0};
        private final long[] offsetY = {-1, 0, 0, 1};
        /**
         * Die Variable index zaehlt die vier Moeglichkeiten durch 
         */
        private int index = 0;
        private int x = free % width;
        private int y = free / width;
        
        @Override
        public boolean hasNext() {
        	// Suche die naechste Nachbarposition des Leerfeldes,
        	// die noch auf dem Spielfeld liegt
            while (index<offsetX.length && 
                    (x+offsetX[index]<0 || x+offsetX[index]>=width ||
                            y+offsetY[index]<0 || y+offsetY[index]>=height)) // invalid field 
            {
                index++;
            }
            // Wenn index<4 ist, haben wir noch eine gefunden
            return index<offsetX.length;
        }

        @Override
        public State next() {
            while (index<offsetX.length && 
                    (x+offsetX[index]<0 || x+offsetX[index]>=width ||
                            y+offsetY[index]<0 || y+offsetY[index]>=height)) // invalid field 
            {
                index++;
            }
            if (index >= offsetX.length)
                return null;
            // Signatur des neuen Zustands berechnen
            long change = (y + offsetY[index])*width + x + offsetX[index]; // Spielsteinposition, die verschoben wird
            long value = (signature >> change*4) & 0xfl;
            long mask = (-1l) ^ (0xfl << change*4);
            long newsig = signature & mask; // Spielstein an alter Position entfernen...
            newsig = newsig | (value << free*4l); // ... und an neuer einsetzen
            index++;
            
            return new State(width, height, newsig);
        }

        @Override
        public void remove() {
        }
    }
}

