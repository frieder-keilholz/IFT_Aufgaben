/*
 * File PuzzleSolver.java
 * $Id$
 *
 * (c) Copyright 2008 Ralf Vandenhouten
 * All rights reserved
 */
package pushpuzzle;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Stack; 

/**
 * PuzzleSolver fuer Pushpuzzles bis zur Groesse 4x4.
 * @author Ralf Vandenhouten
 * @version $Revision$
 */
public class PuzzleSolver {

    private int width, height;
    private State start;
    private State end;
    
    /**
     * Konstruktor
     * @param width - Breite des Puzzles
     * @param height - Hoehe des Puzzles
     * @param start - Startzustand des Puzzles
     */
    public PuzzleSolver(int width, int height, State start) {
        this.width = width;
        this.height = height;
        this.start = start;
        this.end = new State(width, height);
    }
    
    /**
     * Konstruktor, der die Ausgangsstellung aus einer Datei mit diesem Formt liest: </br>
     * <width>
     * <height>
     * <Zahl11><Zahl12>...<Zahl1<width>>
     * ...
     * <Zahl<height>1>...<Zahl<height><width>>
     * 
     * @param filename - Name der Datei mit der Startstellung
     */
    public PuzzleSolver(String filename) {
        try (BufferedReader in = new BufferedReader(
                    new InputStreamReader(new FileInputStream(filename)));)
        {
            width = Integer.parseInt(in.readLine());
            height = Integer.parseInt(in.readLine());
            long signature = 0;
            for (int i=0; i<height; i++) {
                String s = in.readLine();
                for (int j=0; j<width; j++) {
                    char c = s.charAt(j);
                    long value;
                    if (Character.isDigit(c))
                        value = c - '0';
                    else
                        switch (c) {
                            case 'A':
                                value = 10;
                                break;
                            case 'B':
                                value = 11;
                                break;
                            case 'C':
                                value = 12;
                                break;
                            case 'D':
                                value = 13;
                                break;
                            case 'E':
                                value = 14;
                                break;
                            case 'F':
                                value = 15;
                                break;
                            default:
                                throw new NumberFormatException("Wrong input!!!");    
                        }
                    signature += value << (4*(i*width+j));
                }
            }
            start = new State(width, height, signature);
            System.out.println("Start state: " + start);
            end = new State(width, height);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Iterative Tiefensuche
     * @return das Ergebnis als Liste
     */
    public List<State> solve() {
        int maxDepth = 1;
        while (true) {
            System.out.println("Max. depth: " + maxDepth);
            List<State> result = solve(maxDepth++);
            if (result != null)
                return result;
        }
    }
    
    /**
     * Tiefensuche mit Stack
     * @param maxDepth - maximale Suchtiefe
     * @return das Ergebnis als Liste, wenn eines gefunden wurde, andernfalls null
     */
    public List<State> solve(int maxDepth) {
        List<State> result = new ArrayList<State>(maxDepth+1);
        HashSet<State> visited = new HashSet<State>();
        Stack<Iterator<State>> stack = new Stack<Iterator<State>>();
        result.add(start);
        visited.add(start);
        // Iterator auf stack, Iterator enthaelt Nachbarfeldzustaende
        stack.push(start.iterator());
        int index = 0;

        while (!stack.empty()) {
            Iterator<State> it = stack.peek();
            if (it.hasNext()) {
                State state = it.next();
                if (state.equals(end)) { // fertig!
                    result.add(index+1, state);
                    return result;
                }
                // Wenn maximale Suchtiefe noch nicht erreicht und Spielzustand noch nicht besucht ...
                if (index<maxDepth && !visited.contains(state)) {
                    index++;
                    result.add(index, state);
                    visited.add(state);
                    stack.push(state.iterator());
                } else {
                    continue;
                }
            } else {
                // Von hier aus gibt es keine weiteren Moeglichkeiten mehr
                // Also zurueck...
                stack.pop();
                // da iterativ: aus visited entfernen, damit er fuer kuerzere Wege noch verfuegbar ist
                visited.remove(result.get(index));
                result.remove(index--);
            }
        }
        
        return null;
    }
    
    /**
     * Hauptprogramm
     */
    public static void main(String[] args) {
//        State state = new State(3, 3);
//        System.out.println("" + state + state.getSignature());
//        for (State neighb: state)
//            System.out.println(neighb);
        PuzzleSolver ps = new PuzzleSolver("State10.txt");
        long time = System.currentTimeMillis();
        List<State> result = ps.solve();
        time = System.currentTimeMillis() - time;
        System.out.println("Solution with " + (result.size()-1) 
                + " moves found in " + time + "ms:\n\n" + result);
    }
}
