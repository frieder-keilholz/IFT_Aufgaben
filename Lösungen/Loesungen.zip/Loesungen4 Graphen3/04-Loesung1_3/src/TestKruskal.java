import java.util.Set;

import graph.*;
import graph.algorithm.*;

public class TestKruskal {

	public TestKruskal() throws Exception {
		WeightedGraph graph = new WeightedGraphImpl(false);
		WeightedGraph minimumSpanningTree;
		Vertex  v1, v2, v3, v4, v5, v6;

		// Beispielgraph aus der Vorlesung
		v1 = new Vertex( "1" );
		v2 = new Vertex( "2" );
		v3 = new Vertex( "3" );
		v4 = new Vertex( "4" );
		v5 = new Vertex( "5" );
		v6 = new Vertex( "6" );

		graph.addEdge( v1, v2, 2 );
		graph.addEdge( v1, v6, 1 );
		graph.addEdge( v2, v3, 7 );
		graph.addEdge( v2, v6, 1 );
		graph.addEdge( v3, v4, 6 );
		graph.addEdge( v3, v5, 2 );
		graph.addEdge( v3, v6, 2 );
		graph.addEdge( v4, v5, 4 );
		graph.addEdge( v4, v6, 5 );
		graph.addEdge( v5, v6, 2 );

		// Teste Kruskal-Algorithmus
		System.out.println("Graph:\n" + graph);
		MinSpanTreeKruskalAlgorithm kruskal = new MinSpanTreeKruskalAlgorithm(graph);
		minimumSpanningTree = kruskal.minimumSpanningTree();
		System.out.println("Minimum spanning tree:\n" + minimumSpanningTree);
        double sum = 0;
        @SuppressWarnings("unchecked")
		Set<WeightedEdge> edges = (Set<WeightedEdge>)minimumSpanningTree.getAllEdges();
        for (WeightedEdge edge : edges) {
            sum += edge.getWeight();
        }
        System.out.println("Total length: " + sum);
	}

	public static void main(String[] args) throws Exception {
		@SuppressWarnings("unused")
		TestKruskal test = new TestKruskal();
	}
}
