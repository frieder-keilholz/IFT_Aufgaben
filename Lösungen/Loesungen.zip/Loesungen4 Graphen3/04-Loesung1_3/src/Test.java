import graph.*;
import graph.algorithm.MinSpanTreeKruskalAlgorithm;
import graph.algorithm.RealDepthFirstGraphTraversal;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Test {

	public Test() throws Exception {
		WeightedGraph graph = new WeightedGraphImpl(false);
		WeightedGraph minimumSpanningTree;
		Vertex vertex;
		List<Vertex> vertexes = new ArrayList<>();

		int COUNT = 30;

		for(int i=1; i <= COUNT; i++) {
			vertex = new Vertex(i);
			vertexes.add(vertex);
			graph.add(vertex);
		}

		for (int i=1; i <= COUNT; i++) {
			for (int j=1; j <= COUNT; j++) {
				graph.addEdge(vertexes.get(i - 1), vertexes.get(j - 1), 2*(Math.abs(i-j))*j);
			}
		}

		// Teste Kruskal-Algorithmus
		System.out.println("Graph:\n" + graph);
		MinSpanTreeKruskalAlgorithm kruskal = new MinSpanTreeKruskalAlgorithm(graph);
		minimumSpanningTree = kruskal.minimumSpanningTree();
		System.out.println("Minimum spanning tree:\n" + minimumSpanningTree);
        double sum = 0;
        @SuppressWarnings("unchecked")
		Set<WeightedEdge> edges = (Set<WeightedEdge>)minimumSpanningTree.getAllEdges();
        for (WeightedEdge edge : edges) {
            sum += edge.getWeight();
        }
        System.out.println("Total length: " + sum);
	}

	public static void main(String[] args) throws Exception {
		@SuppressWarnings("unused")
        Test test = new Test();
	}
}
